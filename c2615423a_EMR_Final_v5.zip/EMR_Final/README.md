# نظام السجلات الطبية الإلكترونية — EMR System

> **ملاحظة:** هذا الإصدار المُصحَّح من المشروع. راجع قسم "الإصلاحات" أدناه للاطلاع على كل التغييرات.

---

## متطلبات التشغيل

| أداة | الإصدار المطلوب |
|------|----------------|
| Node.js | ≥ 18 |
| npm | ≥ 9 |
| PostgreSQL | ≥ 14 |

---

## خطوات التشغيل

### 1. إعداد قاعدة البيانات

```bash
# أنشئ قاعدة البيانات
psql -U postgres -c "CREATE DATABASE emr_system;"

# شغّل ملف الـ SQL لإنشاء الجداول
psql -U postgres -d emr_system -f db/init.sql
```

### 2. تشغيل الـ Backend

```bash
cd backend

# 1. انسخ ملف البيئة وعدّل كلمة سر PostgreSQL
cp .env .env.local    # أو عدّل .env مباشرة

# 2. ثبّت الـ packages
npm install

# 3. شغّل السيرفر
npm run dev      # للتطوير (مع nodemon)
# أو
npm start        # للإنتاج
```

السيرفر يشتغل على: **http://localhost:5000**

### 3. تشغيل الـ Frontend

```bash
cd frontend

# 1. ثبّت الـ packages
npm install

# 2. شغّل الـ dev server
npm run dev
```

الواجهة تشتغل على: **http://localhost:3000**

---

## إعداد ملف `.env` (Backend)

```env
PORT=5000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=emr_system
DB_USER=postgres
DB_PASSWORD=YOUR_POSTGRES_PASSWORD_HERE   # ← عدّل هذا!

JWT_SECRET=change_this_to_long_random_string_min_32_chars
JWT_EXPIRES_IN=1h
JWT_REFRESH_EXPIRES_IN=7d

CORS_ORIGIN=http://localhost:3000
```

---

## حسابات للاختبار

أنشئ مستخدم admin بتشغيل هذا الـ SQL:

```sql
INSERT INTO users (email, full_name, role, password_hash, is_active, is_verified)
VALUES (
  'admin@emr.local',
  'System Administrator',
  'admin',
  '$2a$10$rOzJqXjFqXjbXf1v2rQ8reAQpF4TvvZ0K.YGhS6mBvlQmCb7.HNJ2',  -- password: Admin@123
  true,
  true
);
```

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@emr.local | Admin@123 |

---

## الإصلاحات المُنجَزة

### Frontend

| الملف | المشكلة | الحل |
|-------|---------|------|
| `AuthContext.jsx` | `login()` يتوقع `accessToken` لكن `register()` كان يتوقع `token` → inconsistency | دعم كلاهما + حفظ refresh token |
| `AuthContext.jsx` | `useEffect` يعيد-run عند تغيير `token` → حلقة لانهائية محتملة | تشغيله مرة واحدة فقط عند mount |
| `App.jsx` | `createContext` مستوردة ولا تُستخدم → warning | حذف الـ import غير المستخدم |
| `Login.jsx` | `isDark` class على الـ `div` لكن dark mode يعمل عبر `data-theme` → dark لا يشتغل | حذف الـ class وترك CSS vars تعمل |
| `Register.jsx` | نفس مشكلة dark mode + لا يوجد icon للـ phone/date fields | إصلاح + إضافة icons |
| `Login.css` | `input-icon` position: absolute right: fixed → ينكسر في RTL | استخدام `inset-inline-start` (logical property) |
| `Login.css` | `input-with-icon` padding فقط على اليمين → overlap مع icon | استخدام `padding-inline-start` |
| `Sidebar.jsx` | Mobile: backdrop يظهر عند `!collapsed` لكن collapsed=false = مفتوح ✓ — كان الـ `mobile-open` class مفقوداً | إضافة class `mobile-open` منفصل |
| `Sidebar.css` | Mobile: `translateX(-100%)` يخفي sidebar لليسار لكنه على اليمين → لا يشتغل | تصحيح إلى `translateX(100%)` |
| `Sidebar.css` | Dark mode عبر `.dark` class لكن ThemeContext يستخدم `[data-theme="dark"]` | تغيير إلى `[data-theme="dark"]` |
| `global.css` | `margin-right: 280px` + `[dir=rtl]` يدوي → عرضة للخطأ | استبدال بـ `margin-inline-end` |
| `Header.jsx` | Dropdown يستخدم `display: showX ? 'block' : 'none'` مع framer-motion animate → يختفي فوراً بدون animation | استبدال بـ `AnimatePresence` |
| `Header.jsx` | Logout لا يعيد redirect لصفحة Login | إضافة `navigate('/login')` بعد logout |

### Backend

| الملف | المشكلة | الحل |
|-------|---------|------|
| `routes/auth.js` | Register endpoint يرجع `{ token, user }` لكن Login يرجع `{ accessToken }` → AuthContext ينكسر | إضافة `accessToken` في register response |
| `.env` | ملف `.env` غير موجود في المشروع | إنشاء `.env` جاهز مع قيم افتراضية |

---

## هيكل المشروع

```
EMR System/
├── backend/                  # Node.js + Express + PostgreSQL
│   ├── .env                  # متغيرات البيئة ← عدّل كلمة سر DB
│   ├── server.js             # نقطة الدخول
│   ├── config/database.js    # إعداد PostgreSQL
│   ├── middleware/
│   │   ├── auth.js           # JWT verification
│   │   └── roleCheck.js      # Role-based access
│   └── routes/
│       ├── auth.js           # Login / Register / Logout
│       ├── patients.js
│       ├── visits.js
│       ├── prescriptions.js
│       ├── labRequests.js
│       ├── appointments.js
│       ├── users.js (admin)
│       └── reports.js
│
├── frontend/                 # React + Vite
│   └── src/
│       ├── context/
│       │   ├── AuthContext.jsx     # ← مُصحَّح
│       │   ├── ThemeContext.jsx
│       │   └── LanguageContext.jsx
│       ├── components/layout/
│       │   ├── Sidebar.jsx         # ← مُصحَّح
│       │   ├── Sidebar.css         # ← مُصحَّح
│       │   ├── Header.jsx          # ← مُصحَّح
│       │   └── Header.css
│       ├── pages/
│       │   ├── auth/Login.jsx      # ← مُصحَّح
│       │   ├── auth/Login.css      # ← مُصحَّح
│       │   ├── auth/Register.jsx   # ← مُصحَّح
│       │   ├── dashboard/
│       │   ├── patients/
│       │   ├── visits/
│       │   ├── prescriptions/
│       │   ├── appointments/
│       │   ├── lab/
│       │   ├── admin/
│       │   └── settings/
│       └── styles/
│           └── global.css          # ← مُصحَّح
│
└── db/
    └── init.sql              # SQL لإنشاء الجداول
```
