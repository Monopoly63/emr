import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'

// Global styles — order matters
import './styles/tokens.css'
import './styles/base.css'
import './styles/components.css'
import './styles/utils.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
