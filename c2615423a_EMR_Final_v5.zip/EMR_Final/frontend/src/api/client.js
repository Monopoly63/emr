/**
 * Axios client — Fixed
 * مع proxy في vite.config يشتغل على /api مباشرة
 */
import axios from 'axios'

// مع proxy: استخدم '/api' فقط
// بدون proxy: ضع الـ URL الكامل في VITE_API_URL
const BASE_URL = import.meta.env.VITE_API_URL || '/api'

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
})

// ── Request: attach token ─────────────────────────────────────
client.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('emr-token')
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  },
  (error) => Promise.reject(error)
)

// ── Response: handle 401 ──────────────────────────────────────
client.interceptors.response.use(
  (res) => res,
  async (error) => {
    const status = error.response?.status

    // Don't redirect on login/register calls
    const url = error.config?.url || ''
    const isAuthCall = url.includes('/auth/login') || url.includes('/auth/register')

    if (status === 401 && !isAuthCall) {
      localStorage.removeItem('emr-token')
      localStorage.removeItem('emr-refresh-token')
      // Avoid redirect loop
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login'
      }
    }

    return Promise.reject(error)
  }
)

export default client
