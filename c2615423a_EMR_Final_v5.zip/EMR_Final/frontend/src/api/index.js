/**
 * API Layer — كل العمليات الحقيقية مع الـ backend
 * لا يوجد mock data هنا — كل شيء يذهب للـ PostgreSQL
 */
import client from './client'

// ─── Auth ────────────────────────────────────────────────────────────────────
export const authAPI = {
  login:          (data)  => client.post('/auth/login', data),
  register:       (data)  => client.post('/auth/register', data),
  logout:         (data)  => client.post('/auth/logout', data),
  me:             ()      => client.get('/auth/me'),
  changePassword: (data)  => client.post('/auth/change-password', data),
  refresh:        (data)  => client.post('/auth/refresh', data),
}

// ─── Patients ────────────────────────────────────────────────────────────────
export const patientsAPI = {
  list:   (params) => client.get('/patients', { params }),
  get:    (id)     => client.get(`/patients/${id}`),
  create: (data)   => client.post('/patients', data),
  update: (id, data) => client.put(`/patients/${id}`, data),
  delete: (id)     => client.delete(`/patients/${id}`),
  // Medical record
  getMedicalRecord: (id) => client.get(`/patients/${id}/medical-record`),
}

// ─── Visits ──────────────────────────────────────────────────────────────────
export const visitsAPI = {
  list:       (params)   => client.get('/visits', { params }),
  forPatient: (patientId, params) => client.get(`/visits/patient/${patientId}`, { params }),
  get:        (id)       => client.get(`/visits/${id}`),
  create:     (data)     => client.post('/visits', data),
  update:     (id, data) => client.put(`/visits/${id}`, data),
  addNote:    (id, data) => client.post(`/visits/${id}/notes`, data),
}

// ─── Prescriptions ───────────────────────────────────────────────────────────
export const prescriptionsAPI = {
  list:       (params)   => client.get('/prescriptions', { params }),
  forPatient: (patientId, params) => client.get(`/prescriptions/patient/${patientId}`, { params }),
  get:        (id)       => client.get(`/prescriptions/${id}`),
  create:     (data)     => client.post('/prescriptions', data),
  dispense:   (id)       => client.patch(`/prescriptions/${id}/dispense`),
}

// ─── Appointments ────────────────────────────────────────────────────────────
export const appointmentsAPI = {
  list:    (params)   => client.get('/appointments', { params }),
  get:     (id)       => client.get(`/appointments/${id}`),
  create:  (data)     => client.post('/appointments', data),
  update:  (id, data) => client.patch(`/appointments/${id}`, data),
  confirm: (id)       => client.patch(`/appointments/${id}`, { status: 'confirmed' }),
  cancel:  (id)       => client.patch(`/appointments/${id}`, { status: 'cancelled' }),
}

// ─── Lab Requests ────────────────────────────────────────────────────────────
export const labAPI = {
  list:          (params)   => client.get('/lab-requests', { params }),
  forPatient:    (patientId, params) => client.get(`/lab-requests/patient/${patientId}`, { params }),
  get:           (id)       => client.get(`/lab-requests/${id}`),
  create:        (data)     => client.post('/lab-requests', data),
  uploadResults: (id, formData) => client.post(`/lab-requests/${id}/results`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
}

// ─── Users (Admin) ───────────────────────────────────────────────────────────
export const usersAPI = {
  list:   (params)   => client.get('/users', { params }),
  get:    (id)       => client.get(`/users/${id}`),
  create: (data)     => client.post('/users', data),
  update: (id, data) => client.put(`/users/${id}`, data),
  verify: (id)       => client.patch(`/users/${id}/verify`),
  toggleActive: (id) => client.patch(`/users/${id}/toggle-active`),
}

// ─── Reports ─────────────────────────────────────────────────────────────────
export const reportsAPI = {
  dashboard: () => client.get('/reports/dashboard'),
}
