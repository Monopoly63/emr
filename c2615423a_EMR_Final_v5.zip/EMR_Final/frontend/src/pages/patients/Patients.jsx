import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Search, Plus, Users, ChevronRight, X, AlertCircle, User, Phone, Mail, Calendar } from 'lucide-react'
import { useLanguage }  from '../../context/LanguageContext'
import { patientsAPI }  from '../../api'

export default function Patients() {
  const { t } = useLanguage()

  const [patients, setPatients]   = useState([])
  const [total,    setTotal]      = useState(0)
  const [page,     setPage]       = useState(1)
  const [pages,    setPages]      = useState(1)
  const [search,   setSearch]     = useState('')
  const [loading,  setLoading]    = useState(true)
  const [error,    setError]      = useState('')
  const [showModal, setShowModal] = useState(false)
  const [saving,   setSaving]     = useState(false)
  const [formErr,  setFormErr]    = useState('')

  const emptyForm = { national_id:'', full_name:'', email:'', phone:'', date_of_birth:'', gender:'male', address:'' }
  const [form, setForm] = useState(emptyForm)

  // ── Fetch ─────────────────────────────────────────────────
  const fetchPatients = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const res = await patientsAPI.list({ search, page, limit: 12 })
      const d   = res.data
      setPatients(d.patients || d || [])
      setTotal(d.pagination?.total ?? (d.patients?.length ?? 0))
      setPages(d.pagination?.totalPages ?? 1)
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally {
      setLoading(false)
    }
  }, [search, page])

  useEffect(() => { fetchPatients() }, [fetchPatients])

  // Debounce search → reset page
  useEffect(() => { setPage(1) }, [search])

  // ── Add Patient ───────────────────────────────────────────
  const handleAdd = async (e) => {
    e.preventDefault(); setFormErr(''); setSaving(true)
    try {
      await patientsAPI.create(form)
      setShowModal(false); setForm(emptyForm); fetchPatients()
    } catch (err) {
      setFormErr(err.response?.data?.error || t('operation_failed'))
    } finally { setSaving(false) }
  }

  return (
    <div>
      {/* ── Header ──────────────────────────── */}
      <div className="page-header">
        <div>
          <h1 className="page-title"><Users size={24} /> {t('patients')}</h1>
          <p className="page-subtitle">{t('patients_subtitle')}</p>
        </div>
        <div className="page-actions">
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={18} /> {t('add_patient')}
          </button>
        </div>
      </div>

      {/* ── Search ──────────────────────────── */}
      <div className="search-bar">
        <div className="search-input-wrap">
          <Search size={16} className="search-icon" />
          <input
            type="search"
            className="input"
            style={{ paddingInlineStart: 40 }}
            placeholder={`${t('search')} ${t('by_name_id_phone')}…`}
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <span style={{ color: 'var(--c-text-4)', fontSize: '.85rem' }}>
          {total} {t('patients')}
        </span>
      </div>

      {/* ── Error ───────────────────────────── */}
      {error && (
        <div className="alert alert-danger" style={{ marginBottom: 16 }}>
          <AlertCircle size={16} /><span>{error}</span>
        </div>
      )}

      {/* ── Grid ────────────────────────────── */}
      {loading ? (
        <div className="spinner-center"><div className="spinner" /></div>
      ) : patients.length === 0 ? (
        <div className="empty-state">
          <Users size={48} />
          <h3>{t('no_patients_found')}</h3>
          <p>{t('try_different_search')}</p>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={16} /> {t('add_patient')}
          </button>
        </div>
      ) : (
        <div className="patients-grid">
          {patients.map((p, i) => (
            <motion.div
              key={p.id}
              className="patient-card"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * .04 }}
            >
              <div className="pc-head">
                <div className="avatar avatar-md">
                  {p.full_name?.charAt(0)?.toUpperCase() || 'P'}
                </div>
                <div className="pc-info">
                  <h3 className="pc-name">{p.full_name}</h3>
                  <span style={{ fontSize: '.8rem', color: 'var(--c-text-4)' }}>#{p.national_id}</span>
                </div>
              </div>
              <div className="pc-details">
                {p.phone && (
                  <div className="pc-row">
                    <Phone size={14} /><span>{p.phone}</span>
                  </div>
                )}
                {p.email && (
                  <div className="pc-row">
                    <Mail size={14} />
                    <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.email}</span>
                  </div>
                )}
                {p.date_of_birth && (
                  <div className="pc-row">
                    <Calendar size={14} /><span>{new Date(p.date_of_birth).toLocaleDateString()}</span>
                  </div>
                )}
              </div>
              <Link to={`/patients/${p.id}`} className="btn btn-ghost btn-full btn-sm" style={{ marginTop: 8, justifyContent:'space-between' }}>
                {t('patient_details')} <ChevronRight size={16} />
              </Link>
            </motion.div>
          ))}
        </div>
      )}

      {/* ── Pagination ──────────────────────── */}
      {pages > 1 && (
        <div className="pagination">
          <span>{t('page')} {page} {t('of')} {pages}</span>
          <div className="pagination-btns">
            <button className="btn btn-ghost btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
              ‹ {t('prev')}
            </button>
            <button className="btn btn-ghost btn-sm" disabled={page === pages} onClick={() => setPage(p => p + 1)}>
              {t('next')} ›
            </button>
          </div>
        </div>
      )}

      {/* ── Add Patient Modal ────────────────── */}
      {showModal && (
        <div className="modal-backdrop" onClick={() => setShowModal(false)}>
          <motion.div
            className="modal-box"
            initial={{ opacity: 0, scale: .96 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={e => e.stopPropagation()}
          >
            <div className="modal-head">
              <h3>{t('add_patient')}</h3>
              <button className="modal-close-btn" onClick={() => setShowModal(false)}><X size={18} /></button>
            </div>
            <form onSubmit={handleAdd}>
              <div className="modal-body">
                {formErr && (
                  <div className="alert alert-danger" style={{ marginBottom: 16 }}>
                    <AlertCircle size={16} /><span>{formErr}</span>
                  </div>
                )}
                <div className="form-grid form-grid-2">
                  <div className="input-group">
                    <label className="input-label required">{t('national_id')}</label>
                    <input className="input" value={form.national_id} onChange={e => setForm({...form,national_id:e.target.value})} required />
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('full_name')}</label>
                    <input className="input" value={form.full_name} onChange={e => setForm({...form,full_name:e.target.value})} required />
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('email')}</label>
                    <input type="email" className="input" value={form.email} onChange={e => setForm({...form,email:e.target.value})} required />
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('phone')}</label>
                    <input type="tel" className="input" value={form.phone} onChange={e => setForm({...form,phone:e.target.value})} />
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('date_of_birth')}</label>
                    <input type="date" className="input" value={form.date_of_birth} onChange={e => setForm({...form,date_of_birth:e.target.value})} />
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('gender')}</label>
                    <select className="input" value={form.gender} onChange={e => setForm({...form,gender:e.target.value})}>
                      <option value="male">{t('male')}</option>
                      <option value="female">{t('female')}</option>
                    </select>
                  </div>
                  <div className="input-group" style={{ gridColumn: '1/-1' }}>
                    <label className="input-label">{t('address')}</label>
                    <input className="input" value={form.address} onChange={e => setForm({...form,address:e.target.value})} />
                  </div>
                </div>
              </div>
              <div className="modal-foot">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>{t('cancel')}</button>
                <button type="submit" className={`btn btn-primary ${saving ? 'btn-loading' : ''}`} disabled={saving}>
                  {!saving && t('save')}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  )
}
