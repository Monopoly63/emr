import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  ArrowLeft, User, Phone, Mail, Calendar, Activity,
  Pill, FlaskConical, AlertCircle, RefreshCw
} from 'lucide-react'
import { useLanguage }   from '../../context/LanguageContext'
import { patientsAPI, visitsAPI, prescriptionsAPI, labAPI } from '../../api'

export default function PatientDetail() {
  const { id }      = useParams()
  const navigate    = useNavigate()
  const { t, direction } = useLanguage()

  const [patient, setPatient]    = useState(null)
  const [visits,  setVisits]     = useState([])
  const [rxList,  setRxList]     = useState([])
  const [labs,    setLabs]       = useState([])
  const [loading, setLoading]    = useState(true)
  const [error,   setError]      = useState('')

  const load = async () => {
    setLoading(true); setError('')
    try {
      const [pRes, vRes, rRes, lRes] = await Promise.allSettled([
        patientsAPI.get(id),
        visitsAPI.forPatient(id, { limit: 10 }),
        prescriptionsAPI.forPatient(id, { limit: 10 }),
        labAPI.forPatient(id, { limit: 10 }),
      ])
      if (pRes.status === 'fulfilled') setPatient(pRes.value.data)
      else setError(t('operation_failed'))
      if (vRes.status === 'fulfilled') setVisits(vRes.value.data?.visits || vRes.value.data || [])
      if (rRes.status === 'fulfilled') setRxList(rRes.value.data?.prescriptions || rRes.value.data || [])
      if (lRes.status === 'fulfilled') setLabs(lRes.value.data?.lab_requests || lRes.value.data || [])
    } catch { setError(t('operation_failed')) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [id])

  if (loading) return <div className="spinner-center"><div className="spinner"/></div>
  if (error)   return (
    <div>
      <button className="btn btn-ghost" onClick={() => navigate(-1)} style={{ marginBottom:'var(--sp-4)' }}>
        <ArrowLeft size={18} style={{ transform: direction==='rtl'?'scaleX(-1)':undefined }}/> {t('prev')}
      </button>
      <div className="alert alert-danger"><AlertCircle size={16}/><span>{error}</span></div>
    </div>
  )
  if (!patient) return null

  return (
    <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }}>
      {/* Back */}
      <button
        className="btn btn-ghost"
        onClick={() => navigate('/patients')}
        style={{ marginBottom:'var(--sp-4)' }}
      >
        <ArrowLeft size={18} style={{ transform: direction==='rtl'?'scaleX(-1)':undefined }}/>
        {t('patients')}
      </button>

      {/* Patient Card */}
      <div className="card" style={{ marginBottom:'var(--sp-5)' }}>
        <div className="card-body">
          <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-5)', flexWrap:'wrap' }}>
            <div className="avatar avatar-xl">{patient.full_name?.charAt(0)?.toUpperCase()||'P'}</div>
            <div style={{ flex:1, minWidth:200 }}>
              <h2 style={{ color:'var(--c-text)', marginBottom:4 }}>{patient.full_name}</h2>
              <p style={{ color:'var(--c-text-4)', fontSize:'.85rem', marginBottom:12 }}>#{patient.national_id}</p>
              <div style={{ display:'flex', gap:'var(--sp-5)', flexWrap:'wrap' }}>
                {patient.phone && (
                  <span style={{ display:'flex', alignItems:'center', gap:6, color:'var(--c-text-2)', fontSize:'.9rem' }}>
                    <Phone size={14}/>{patient.phone}
                  </span>
                )}
                {patient.email && (
                  <span style={{ display:'flex', alignItems:'center', gap:6, color:'var(--c-text-2)', fontSize:'.9rem' }}>
                    <Mail size={14}/>{patient.email}
                  </span>
                )}
                {patient.date_of_birth && (
                  <span style={{ display:'flex', alignItems:'center', gap:6, color:'var(--c-text-2)', fontSize:'.9rem' }}>
                    <Calendar size={14}/>{new Date(patient.date_of_birth).toLocaleDateString()}
                  </span>
                )}
                {patient.gender && (
                  <span style={{ display:'flex', alignItems:'center', gap:6, color:'var(--c-text-2)', fontSize:'.9rem' }}>
                    <User size={14}/>{t(patient.gender)}
                  </span>
                )}
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={load}><RefreshCw size={14}/></button>
          </div>
        </div>
      </div>

      {/* Tabs sections */}
      <div className="detail-grid">
        {/* Visits */}
        <div className="card">
          <div className="card-header">
            <h3><Activity size={16}/> {t('visits')} ({visits.length})</h3>
          </div>
          <div style={{ padding: 0 }}>
            {visits.length === 0 ? (
              <div className="empty-state" style={{ padding:'var(--sp-6)' }}><Activity size={32}/><p>{t('no_visits_found')}</p></div>
            ) : (
              visits.map(v => (
                <div key={v.id} className="detail-list-item">
                  <div>
                    <p style={{ fontWeight:600, color:'var(--c-text)' }}>{v.complaint}</p>
                    {v.diagnosis && <p style={{ fontSize:'.85rem', color:'var(--c-text-3)', marginTop:2 }}>{v.diagnosis}</p>}
                    <p style={{ fontSize:'.8rem', color:'var(--c-text-4)', marginTop:4 }}>
                      {v.created_at ? new Date(v.created_at).toLocaleDateString() : ''} · {v.doctor_name || ''}
                    </p>
                  </div>
                  <span className={`badge ${v.status==='completed'?'badge-success':v.status==='in_progress'?'badge-warning':'badge-primary'}`}>
                    {t(v.status)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Prescriptions */}
        <div className="card">
          <div className="card-header">
            <h3><Pill size={16}/> {t('prescriptions')} ({rxList.length})</h3>
          </div>
          <div style={{ padding: 0 }}>
            {rxList.length === 0 ? (
              <div className="empty-state" style={{ padding:'var(--sp-6)' }}><Pill size={32}/><p>{t('no_prescriptions_found')}</p></div>
            ) : (
              rxList.map(rx => (
                <div key={rx.id} className="detail-list-item">
                  <div>
                    <p style={{ fontWeight:600, color:'var(--c-text)' }}>{rx.medication_name||rx.medication}</p>
                    <p style={{ fontSize:'.85rem', color:'var(--c-text-3)', marginTop:2 }}>{rx.dosage}</p>
                    <p style={{ fontSize:'.8rem', color:'var(--c-text-4)', marginTop:4 }}>
                      {rx.created_at ? new Date(rx.created_at).toLocaleDateString() : ''}
                    </p>
                  </div>
                  <span className={`badge ${rx.status==='dispensed'?'badge-success':'badge-warning'}`}>
                    {t(rx.status)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Lab Requests */}
        <div className="card">
          <div className="card-header">
            <h3><FlaskConical size={16}/> {t('lab_requests')} ({labs.length})</h3>
          </div>
          <div style={{ padding: 0 }}>
            {labs.length === 0 ? (
              <div className="empty-state" style={{ padding:'var(--sp-6)' }}><FlaskConical size={32}/><p>{t('no_lab_requests')}</p></div>
            ) : (
              labs.map(l => (
                <div key={l.id} className="detail-list-item">
                  <div>
                    <p style={{ fontWeight:600, color:'var(--c-text)' }}>{l.test_type}</p>
                    <p style={{ fontSize:'.8rem', color:'var(--c-text-4)', marginTop:4 }}>
                      {l.created_at ? new Date(l.created_at).toLocaleDateString() : ''} · {t(l.urgency||'routine')}
                    </p>
                  </div>
                  <span className={`badge ${l.status==='completed'?'badge-success':l.status==='in_progress'?'badge-warning':'badge-primary'}`}>
                    {t(l.status)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </motion.div>
  )
}
