import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Calendar, Plus, X, AlertCircle, RefreshCw, Clock, User } from 'lucide-react'
import { useLanguage }                      from '../../context/LanguageContext'
import { useAuth }                          from '../../context/AuthContext'
import { appointmentsAPI, patientsAPI, usersAPI } from '../../api'

// Status → badge class
const STATUS_BADGE = {
  scheduled: 'badge-primary',
  confirmed: 'badge-success',
  cancelled: 'badge-danger',
  no_show:   'badge-warning',
  completed: 'badge-neutral',
}

const EMPTY_FORM = { patient_id: '', doctor_id: '', appointment_date: '', notes: '' }

export default function Appointments() {
  const { t }    = useLanguage()
  const { user } = useAuth()

  // ── Data ─────────────────────────────────────────────────────
  const [appts,    setAppts]    = useState([])
  const [patients, setPatients] = useState([])
  const [doctors,  setDoctors]  = useState([])

  // ── UI state ─────────────────────────────────────────────────
  const [loading,    setLoading]    = useState(true)
  const [error,      setError]      = useState('')
  const [filter,     setFilter]     = useState('all')
  const [showModal,  setShowModal]  = useState(false)
  const [saving,     setSaving]     = useState(false)
  const [formErr,    setFormErr]    = useState('')
  const [actionId,   setActionId]   = useState(null)   // tracks which row is loading
  const [form,       setForm]       = useState(EMPTY_FORM)

  // ── Fetch appointments ────────────────────────────────────────
  const fetchAppts = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res    = await appointmentsAPI.list(params)
      // backend returns { appointments: [...] } or raw array
      const data   = res.data?.appointments ?? res.data ?? []
      setAppts(Array.isArray(data) ? data : [])
    } catch (e) {
      const msg = e.response?.data?.error || e.message || t('operation_failed')
      setError(msg)
    } finally {
      setLoading(false)
    }
  }, [filter, t])

  useEffect(() => { fetchAppts() }, [fetchAppts])

  // ── Fetch patients + doctors (for the form) ───────────────────
  useEffect(() => {
    patientsAPI.list({ limit: 200 })
      .then(r => setPatients(r.data?.patients ?? r.data ?? []))
      .catch(() => {})

    usersAPI.list({ role: 'doctor' })
      .then(r => {
        const raw = r.data?.users ?? r.data ?? []
        setDoctors(Array.isArray(raw) ? raw.filter(u => u.role === 'doctor' || !u.role) : [])
      })
      .catch(() => {})
  }, [])

  // ── Status action (confirm / cancel) ─────────────────────────
  const doAction = async (id, status) => {
    setActionId(id)
    try {
      await appointmentsAPI.update(id, { status })
      // Optimistic update
      setAppts(prev => prev.map(a => a.id === id ? { ...a, status } : a))
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally {
      setActionId(null)
    }
  }

  // ── Create appointment ────────────────────────────────────────
  const handleAdd = async (e) => {
    e.preventDefault()
    setFormErr('')

    // Validate
    if (!form.patient_id || !form.doctor_id || !form.appointment_date) {
      setFormErr(t('fill_all_fields'))
      return
    }

    setSaving(true)
    try {
      await appointmentsAPI.create(form)
      setShowModal(false)
      setForm(EMPTY_FORM)
      fetchAppts()
    } catch (err) {
      const msg = err.response?.data?.error
        || err.response?.data?.errors?.[0]?.msg
        || t('operation_failed')
      setFormErr(msg)
    } finally {
      setSaving(false)
    }
  }

  // ── Counts for filter tabs ────────────────────────────────────
  const counts = {
    all:       appts.length,
    scheduled: appts.filter(a => a.status === 'scheduled').length,
    confirmed: appts.filter(a => a.status === 'confirmed').length,
    cancelled: appts.filter(a => a.status === 'cancelled').length,
  }

  // ── Displayed rows (already filtered by backend, but filter here for instant UI) ──
  const displayed = filter === 'all'
    ? appts
    : appts.filter(a => a.status === filter)

  const canBook = ['admin', 'receptionist'].includes(user?.role)

  return (
    <div>
      {/* ── Page header ──────────────────────────────── */}
      <div className="page-header">
        <div>
          <h1 className="page-title">
            <Calendar size={22} /> {t('appointments')}
          </h1>
          <p className="page-subtitle">{t('appointments_subtitle')}</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={fetchAppts} title={t('refresh')} disabled={loading}>
            <RefreshCw size={16} className={loading ? 'spin-icon' : ''} />
          </button>
          {canBook && (
            <button className="btn btn-primary" onClick={() => { setFormErr(''); setForm(EMPTY_FORM); setShowModal(true) }}>
              <Plus size={17} /> {t('book_appointment')}
            </button>
          )}
        </div>
      </div>

      {/* ── Filter tabs ──────────────────────────────── */}
      <div className="filter-tabs">
        {Object.entries(counts).map(([k, c]) => (
          <button
            key={k}
            className={`filter-tab${filter === k ? ' active' : ''}`}
            onClick={() => setFilter(k)}
          >
            {t(k === 'all' ? 'all' : k)}
            <span className="filter-count">{c}</span>
          </button>
        ))}
      </div>

      {/* ── Error banner ─────────────────────────────── */}
      {error && (
        <div className="alert alert-danger" style={{ marginBottom: 16 }}>
          <AlertCircle size={15} />
          <span>{error}</span>
          <button
            style={{ marginInlineStart: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'inherit' }}
            onClick={() => setError('')}
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* ── Content ──────────────────────────────────── */}
      {loading ? (
        <div className="spinner-center"><div className="spinner" /></div>
      ) : displayed.length === 0 ? (
        <div className="empty-state">
          <Calendar size={48} />
          <h3>{t('no_appointments_found')}</h3>
          <p>{canBook ? t('book_first_appointment') : t('no_data_yet')}</p>
          {canBook && (
            <button className="btn btn-primary" onClick={() => setShowModal(true)}>
              <Plus size={16} /> {t('book_appointment')}
            </button>
          )}
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th><User size={13} style={{ marginInlineEnd: 4 }} />{t('patient')}</th>
                <th>{t('doctor')}</th>
                <th><Clock size={13} style={{ marginInlineEnd: 4 }} />{t('date_time')}</th>
                <th>{t('notes')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {displayed.map((a, i) => (
                <motion.tr
                  key={a.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * .025 }}
                >
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <div className="avatar avatar-sm">
                        {(a.patient_name || 'P').charAt(0).toUpperCase()}
                      </div>
                      <span style={{ fontWeight: 500 }}>{a.patient_name || '—'}</span>
                    </div>
                  </td>
                  <td>{a.doctor_name || '—'}</td>
                  <td style={{ whiteSpace: 'nowrap', fontSize: '.85rem' }}>
                    {a.appointment_date
                      ? new Date(a.appointment_date).toLocaleString([], {
                          dateStyle: 'medium', timeStyle: 'short',
                        })
                      : '—'}
                  </td>
                  <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {a.notes || <span style={{ color: 'var(--c-text-4)' }}>—</span>}
                  </td>
                  <td>
                    <span className={`badge ${STATUS_BADGE[a.status] || 'badge-neutral'}`}>
                      {t(a.status)}
                    </span>
                  </td>
                  <td>
                    {a.status === 'scheduled' && canBook && (
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button
                          className="btn btn-sm btn-success"
                          disabled={actionId === a.id}
                          onClick={() => doAction(a.id, 'confirmed')}
                        >
                          {t('confirm')}
                        </button>
                        <button
                          className="btn btn-sm btn-ghost"
                          disabled={actionId === a.id}
                          onClick={() => doAction(a.id, 'cancelled')}
                        >
                          {t('cancel')}
                        </button>
                      </div>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Book appointment modal ────────────────────── */}
      <AnimatePresence>
        {showModal && (
          <div className="modal-backdrop" onClick={() => setShowModal(false)}>
            <motion.div
              className="modal-box"
              style={{ maxWidth: 540 }}
              initial={{ opacity: 0, scale: .95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: .95, y: 10 }}
              transition={{ duration: .2 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="modal-head">
                <h3>{t('book_appointment')}</h3>
                <button className="modal-close-btn" onClick={() => setShowModal(false)}>
                  <X size={17} />
                </button>
              </div>

              <form onSubmit={handleAdd}>
                <div className="modal-body">
                  {formErr && (
                    <div className="alert alert-danger" style={{ marginBottom: 16 }}>
                      <AlertCircle size={15} />
                      <span>{formErr}</span>
                    </div>
                  )}

                  <div className="form-grid form-grid-2">
                    {/* Patient */}
                    <div className="input-group">
                      <label className="input-label required">{t('patient')}</label>
                      <select
                        className="input"
                        value={form.patient_id}
                        onChange={e => setForm({ ...form, patient_id: e.target.value })}
                        required
                      >
                        <option value="">{t('select_patient')}</option>
                        {patients.map(p => (
                          <option key={p.id} value={p.id}>{p.full_name}</option>
                        ))}
                      </select>
                      {patients.length === 0 && (
                        <span style={{ fontSize: '.78rem', color: 'var(--c-text-4)' }}>
                          {t('loading')}…
                        </span>
                      )}
                    </div>

                    {/* Doctor */}
                    <div className="input-group">
                      <label className="input-label required">{t('doctor')}</label>
                      <select
                        className="input"
                        value={form.doctor_id}
                        onChange={e => setForm({ ...form, doctor_id: e.target.value })}
                        required
                      >
                        <option value="">{t('select_doctor')}</option>
                        {doctors.map(d => (
                          <option key={d.id} value={d.id}>{d.full_name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Date + Time */}
                    <div className="input-group" style={{ gridColumn: '1 / -1' }}>
                      <label className="input-label required">{t('date_time')}</label>
                      <input
                        type="datetime-local"
                        className="input"
                        value={form.appointment_date}
                        onChange={e => setForm({ ...form, appointment_date: e.target.value })}
                        min={new Date().toISOString().slice(0, 16)}
                        required
                      />
                    </div>

                    {/* Notes */}
                    <div className="input-group" style={{ gridColumn: '1 / -1' }}>
                      <label className="input-label">{t('notes')}</label>
                      <textarea
                        className="input"
                        rows={2}
                        value={form.notes}
                        onChange={e => setForm({ ...form, notes: e.target.value })}
                        placeholder={t('optional')}
                        style={{ resize: 'vertical' }}
                      />
                    </div>
                  </div>
                </div>

                <div className="modal-foot">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowModal(false)}
                    disabled={saving}
                  >
                    {t('cancel')}
                  </button>
                  <button
                    type="submit"
                    className={`btn btn-primary${saving ? ' btn-loading' : ''}`}
                    disabled={saving}
                  >
                    {!saving && <><Plus size={15} /> {t('save')}</>}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}
