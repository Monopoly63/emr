import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Pill, Plus, X, AlertCircle, AlertTriangle } from 'lucide-react'
import { useLanguage }       from '../../context/LanguageContext'
import { useAuth }           from '../../context/AuthContext'
import { prescriptionsAPI, patientsAPI } from '../../api'

const STATUS_MAP = {
  pending:   'badge-warning',
  dispensed: 'badge-success',
  cancelled: 'badge-danger',
}

export default function Prescriptions() {
  const { t }    = useLanguage()
  const { user } = useAuth()

  const [rxList,  setRxList]   = useState([])
  const [loading, setLoading]  = useState(true)
  const [error,   setError]    = useState('')
  const [filter,  setFilter]   = useState('all')
  const [showModal, setShowModal] = useState(false)
  const [saving,  setSaving]   = useState(false)
  const [formErr, setFormErr]  = useState('')
  const [patients, setPatients] = useState([])

  const emptyForm = { patient_id:'', medication_name:'', dosage:'', frequency:'', duration_days:'', instructions:'', is_urgent: false }
  const [form, setForm] = useState(emptyForm)

  const fetchRx = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await prescriptionsAPI.list(params)
      setRxList(res.data?.prescriptions || res.data || [])
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally { setLoading(false) }
  }, [filter])

  useEffect(() => { fetchRx() }, [fetchRx])

  useEffect(() => {
    patientsAPI.list({ limit: 200 }).then(r => setPatients(r.data?.patients || r.data || [])).catch(()=>{})
  }, [])

  const dispense = async (id) => {
    try { await prescriptionsAPI.dispense(id); fetchRx() }
    catch { setError(t('operation_failed')) }
  }

  const handleAdd = async (e) => {
    e.preventDefault(); setFormErr(''); setSaving(true)
    try {
      await prescriptionsAPI.create({ ...form, prescribed_by: user?.id })
      setShowModal(false); setForm(emptyForm); fetchRx()
    } catch (err) {
      setFormErr(err.response?.data?.error || t('operation_failed'))
    } finally { setSaving(false) }
  }

  const counts = {
    all:       rxList.length,
    pending:   rxList.filter(r=>r.status==='pending').length,
    dispensed: rxList.filter(r=>r.status==='dispensed').length,
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title"><Pill size={24}/> {t('prescriptions')}</h1>
          <p className="page-subtitle">{t('prescriptions_subtitle')}</p>
        </div>
        {['admin','doctor'].includes(user?.role) && (
          <button className="btn btn-primary" onClick={()=>setShowModal(true)}>
            <Plus size={18}/> {t('new_prescription')}
          </button>
        )}
      </div>

      <div className="filter-tabs">
        {Object.entries(counts).map(([k,c])=>(
          <button key={k} className={`filter-tab ${filter===k?'active':''}`} onClick={()=>setFilter(k)}>
            {t(k==='all'?'all':k)} <span className="filter-count">{c}</span>
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger"><AlertCircle size={16}/><span>{error}</span></div>}

      {loading ? (
        <div className="spinner-center"><div className="spinner"/></div>
      ) : rxList.length === 0 ? (
        <div className="empty-state"><Pill size={48}/><h3>{t('no_prescriptions_found')}</h3></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('patient')}</th>
                <th>{t('medication')}</th>
                <th>{t('dosage')}</th>
                <th>{t('duration')}</th>
                <th>{t('doctor')}</th>
                <th>{t('date')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {rxList.map((rx,i)=>(
                <motion.tr key={rx.id} className={rx.allergy_alert?'alert-row':''} initial={{opacity:0}} animate={{opacity:1}} transition={{delay:i*.03}}>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <div className="avatar avatar-sm">{(rx.patient_name||'P').charAt(0).toUpperCase()}</div>
                      <span style={{fontWeight:500}}>{rx.patient_name||'—'}</span>
                    </div>
                  </td>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:6}}>
                      {rx.allergy_alert && <AlertTriangle size={14} style={{color:'var(--c-danger)',flexShrink:0}} title={t('allergy_warning')}/>}
                      <strong>{rx.medication_name||rx.medication}</strong>
                    </div>
                  </td>
                  <td>{rx.dosage||'—'}</td>
                  <td>{rx.duration_days ? `${rx.duration_days} ${t('days')}` : '—'}</td>
                  <td>{rx.doctor_name||rx.prescribed_by_name||'—'}</td>
                  <td style={{whiteSpace:'nowrap'}}>{rx.created_at?new Date(rx.created_at).toLocaleDateString():'—'}</td>
                  <td><span className={`badge ${STATUS_MAP[rx.status]||'badge-neutral'}`}>{t(rx.status)}</span></td>
                  <td>
                    {rx.status==='pending' && ['admin','pharmacist'].includes(user?.role) && (
                      <button className="btn btn-sm btn-primary" onClick={()=>dispense(rx.id)}>{t('dispense')}</button>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-backdrop" onClick={()=>setShowModal(false)}>
          <motion.div className="modal-box" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} onClick={e=>e.stopPropagation()}>
            <div className="modal-head">
              <h3>{t('new_prescription')}</h3>
              <button className="modal-close-btn" onClick={()=>setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleAdd}>
              <div className="modal-body">
                {formErr && <div className="alert alert-danger" style={{marginBottom:16}}><AlertCircle size={16}/><span>{formErr}</span></div>}
                <div className="form-grid form-grid-2">
                  <div className="input-group" style={{gridColumn:'1/-1'}}>
                    <label className="input-label required">{t('patient')}</label>
                    <select className="input" value={form.patient_id} onChange={e=>setForm({...form,patient_id:e.target.value})} required>
                      <option value="">{t('select_patient')}</option>
                      {patients.map(p=><option key={p.id} value={p.id}>{p.full_name}</option>)}
                    </select>
                  </div>
                  <div className="input-group" style={{gridColumn:'1/-1'}}>
                    <label className="input-label required">{t('medication')}</label>
                    <input className="input" value={form.medication_name} onChange={e=>setForm({...form,medication_name:e.target.value})} required placeholder="e.g. Amoxicillin 500mg"/>
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('dosage')}</label>
                    <input className="input" value={form.dosage} onChange={e=>setForm({...form,dosage:e.target.value})} required placeholder="e.g. Once daily"/>
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('duration')} ({t('days')})</label>
                    <input type="number" min={1} className="input" value={form.duration_days} onChange={e=>setForm({...form,duration_days:e.target.value})} placeholder="30"/>
                  </div>
                  <div className="input-group" style={{gridColumn:'1/-1'}}>
                    <label className="input-label">{t('instructions')}</label>
                    <textarea className="input" rows={2} value={form.instructions} onChange={e=>setForm({...form,instructions:e.target.value})}/>
                  </div>
                </div>
              </div>
              <div className="modal-foot">
                <button type="button" className="btn btn-secondary" onClick={()=>setShowModal(false)}>{t('cancel')}</button>
                <button type="submit" className={`btn btn-primary ${saving?'btn-loading':''}`} disabled={saving}>{!saving&&t('save')}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  )
}
