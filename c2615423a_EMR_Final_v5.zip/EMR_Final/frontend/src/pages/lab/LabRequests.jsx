import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { FlaskConical, Plus, Upload, X, AlertCircle } from 'lucide-react'
import { useLanguage } from '../../context/LanguageContext'
import { useAuth }     from '../../context/AuthContext'
import { labAPI, patientsAPI } from '../../api'

const STATUS_MAP = {
  pending:     'badge-warning',
  in_progress: 'badge-primary',
  completed:   'badge-success',
  cancelled:   'badge-danger',
}
const URGENCY_MAP = {
  routine: 'badge-neutral',
  urgent:  'badge-warning',
  stat:    'badge-danger',
}

export default function LabRequests() {
  const { t }    = useLanguage()
  const { user } = useAuth()

  const [labs,    setLabs]     = useState([])
  const [loading, setLoading]  = useState(true)
  const [error,   setError]    = useState('')
  const [filter,  setFilter]   = useState('all')
  const [showModal, setShowModal] = useState(false)
  const [saving,  setSaving]   = useState(false)
  const [formErr, setFormErr]  = useState('')
  const [patients, setPatients] = useState([])

  const emptyForm = { patient_id:'', test_type:'', urgency:'routine', notes:'' }
  const [form, setForm] = useState(emptyForm)

  const fetchLabs = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await labAPI.list(params)
      setLabs(res.data?.lab_requests || res.data || [])
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally { setLoading(false) }
  }, [filter])

  useEffect(() => { fetchLabs() }, [fetchLabs])

  useEffect(() => {
    patientsAPI.list({ limit: 200 }).then(r => setPatients(r.data?.patients || r.data || [])).catch(()=>{})
  }, [])

  const handleAdd = async (e) => {
    e.preventDefault(); setFormErr(''); setSaving(true)
    try {
      await labAPI.create({ ...form, ordered_by: user?.id })
      setShowModal(false); setForm(emptyForm); fetchLabs()
    } catch (err) {
      setFormErr(err.response?.data?.error || t('operation_failed'))
    } finally { setSaving(false) }
  }

  const counts = {
    all:         labs.length,
    pending:     labs.filter(l=>l.status==='pending').length,
    in_progress: labs.filter(l=>l.status==='in_progress').length,
    completed:   labs.filter(l=>l.status==='completed').length,
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title"><FlaskConical size={24}/> {t('lab_requests')}</h1>
          <p className="page-subtitle">{t('lab_subtitle')}</p>
        </div>
        {['admin','doctor','lab_tech'].includes(user?.role) && (
          <button className="btn btn-primary" onClick={()=>setShowModal(true)}>
            <Plus size={18}/> {t('new_request')}
          </button>
        )}
      </div>

      <div className="filter-tabs">
        {Object.entries(counts).map(([k,c])=>(
          <button key={k} className={`filter-tab ${filter===k?'active':''}`} onClick={()=>setFilter(k)}>
            {t(k==='all'?'all':k==='in_progress'?'in_progress':k)} <span className="filter-count">{c}</span>
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger"><AlertCircle size={16}/><span>{error}</span></div>}

      {loading ? (
        <div className="spinner-center"><div className="spinner"/></div>
      ) : labs.length === 0 ? (
        <div className="empty-state"><FlaskConical size={48}/><h3>{t('no_lab_requests')}</h3></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('patient')}</th>
                <th>{t('test_type')}</th>
                <th>{t('urgent')}</th>
                <th>{t('doctor')}</th>
                <th>{t('date')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {labs.map((lab,i)=>(
                <motion.tr key={lab.id} initial={{opacity:0}} animate={{opacity:1}} transition={{delay:i*.03}}>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <div className="avatar avatar-sm">{(lab.patient_name||'P').charAt(0).toUpperCase()}</div>
                      <span style={{fontWeight:500}}>{lab.patient_name||'—'}</span>
                    </div>
                  </td>
                  <td><strong>{lab.test_type}</strong></td>
                  <td><span className={`badge ${URGENCY_MAP[lab.urgency]||'badge-neutral'}`}>{t(lab.urgency)}</span></td>
                  <td>{lab.doctor_name||lab.ordered_by_name||'—'}</td>
                  <td style={{whiteSpace:'nowrap'}}>{lab.created_at?new Date(lab.created_at).toLocaleDateString():'—'}</td>
                  <td><span className={`badge ${STATUS_MAP[lab.status]||'badge-neutral'}`}>{t(lab.status==='in_progress'?'in_progress':lab.status)}</span></td>
                  <td>
                    {lab.status !== 'completed' && ['admin','lab_tech'].includes(user?.role) && (
                      <button className="btn btn-sm btn-secondary">
                        <Upload size={14}/> {t('upload_results')}
                      </button>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-backdrop" onClick={()=>setShowModal(false)}>
          <motion.div className="modal-box" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} onClick={e=>e.stopPropagation()}>
            <div className="modal-head">
              <h3>{t('new_request')}</h3>
              <button className="modal-close-btn" onClick={()=>setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleAdd}>
              <div className="modal-body">
                {formErr && <div className="alert alert-danger" style={{marginBottom:16}}><AlertCircle size={16}/><span>{formErr}</span></div>}
                <div className="form-grid">
                  <div className="input-group">
                    <label className="input-label required">{t('patient')}</label>
                    <select className="input" value={form.patient_id} onChange={e=>setForm({...form,patient_id:e.target.value})} required>
                      <option value="">{t('select_patient')}</option>
                      {patients.map(p=><option key={p.id} value={p.id}>{p.full_name}</option>)}
                    </select>
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('test_type')}</label>
                    <input className="input" value={form.test_type} onChange={e=>setForm({...form,test_type:e.target.value})} required placeholder="e.g. Complete Blood Count"/>
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('urgency_level')}</label>
                    <select className="input" value={form.urgency} onChange={e=>setForm({...form,urgency:e.target.value})}>
                      <option value="routine">{t('routine')}</option>
                      <option value="urgent">{t('urgent')}</option>
                      <option value="stat">{t('stat')}</option>
                    </select>
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('notes')}</label>
                    <textarea className="input" rows={2} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
                  </div>
                </div>
              </div>
              <div className="modal-foot">
                <button type="button" className="btn btn-secondary" onClick={()=>setShowModal(false)}>{t('cancel')}</button>
                <button type="submit" className={`btn btn-primary ${saving?'btn-loading':''}`} disabled={saving}>{!saving&&t('save')}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  )
}
