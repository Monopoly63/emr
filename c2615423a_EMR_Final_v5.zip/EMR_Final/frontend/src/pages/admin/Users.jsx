import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { UserCog, Plus, X, AlertCircle, Eye, EyeOff, CheckCircle, XCircle } from 'lucide-react'
import { useLanguage } from '../../context/LanguageContext'
import { usersAPI }    from '../../api'

const ROLE_BADGE = {
  admin:        'badge-danger',
  doctor:       'badge-primary',
  receptionist: 'badge-teal',
  lab_tech:     'badge-warning',
  pharmacist:   'badge-success',
}

export default function Users() {
  const { t } = useLanguage()

  const [users,   setUsers]    = useState([])
  const [loading, setLoading]  = useState(true)
  const [error,   setError]    = useState('')
  const [showModal, setShowModal] = useState(false)
  const [saving,  setSaving]   = useState(false)
  const [formErr, setFormErr]  = useState('')
  const [showPass, setShowPass] = useState(false)

  const emptyForm = { full_name:'', email:'', role:'doctor', password:'' }
  const [form, setForm] = useState(emptyForm)

  const fetchUsers = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const res = await usersAPI.list()
      setUsers(res.data?.users || res.data || [])
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally { setLoading(false) }
  }, [])

  useEffect(() => { fetchUsers() }, [fetchUsers])

  const handleAdd = async (e) => {
    e.preventDefault(); setFormErr(''); setSaving(true)
    try {
      await usersAPI.create(form)
      setShowModal(false); setForm(emptyForm); fetchUsers()
    } catch (err) {
      setFormErr(err.response?.data?.error || t('operation_failed'))
    } finally { setSaving(false) }
  }

  const handleVerify = async (id) => {
    try { await usersAPI.verify(id); fetchUsers() }
    catch { setError(t('operation_failed')) }
  }

  const stats = {
    total:    users.length,
    verified: users.filter(u=>u.is_verified).length,
    pending:  users.filter(u=>!u.is_verified).length,
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title"><UserCog size={24}/> {t('users')}</h1>
          <p className="page-subtitle">{t('users_subtitle')}</p>
        </div>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>
          <Plus size={18}/> {t('add_user')}
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid" style={{gridTemplateColumns:'repeat(3,1fr)',marginBottom:'var(--sp-5)'}}>
        {[
          { label: t('total_users'), value: stats.total, color: 'primary' },
          { label: t('verified'),    value: stats.verified, color: 'success' },
          { label: t('pending_verification'), value: stats.pending, color: 'warning' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className={`stat-icon-wrap ${s.color}`}><UserCog size={20}/></div>
            <div className="stat-body">
              <span className="stat-value">{s.value}</span>
              <span className="stat-label">{s.label}</span>
            </div>
          </div>
        ))}
      </div>

      {error && <div className="alert alert-danger"><AlertCircle size={16}/><span>{error}</span></div>}

      {loading ? (
        <div className="spinner-center"><div className="spinner"/></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('full_name')}</th>
                <th>{t('email')}</th>
                <th>{t('role')}</th>
                <th>{t('verified')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u,i)=>(
                <motion.tr key={u.id} initial={{opacity:0}} animate={{opacity:1}} transition={{delay:i*.03}}>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <div className="avatar avatar-sm">{u.full_name?.charAt(0)?.toUpperCase()||'U'}</div>
                      <strong>{u.full_name}</strong>
                    </div>
                  </td>
                  <td style={{color:'var(--c-text-3)'}}>{u.email}</td>
                  <td><span className={`badge ${ROLE_BADGE[u.role]||'badge-neutral'}`}>{t(u.role)}</span></td>
                  <td>
                    {u.is_verified
                      ? <CheckCircle size={18} style={{color:'var(--c-success)'}}/>
                      : <XCircle    size={18} style={{color:'var(--c-text-4)'}}/>
                    }
                  </td>
                  <td>
                    <span className={`badge ${u.is_active?'badge-success':'badge-neutral'}`}>
                      {u.is_active ? t('active') : t('inactive')}
                    </span>
                  </td>
                  <td>
                    <div style={{display:'flex',gap:6}}>
                      {!u.is_verified && (
                        <button className="btn btn-sm btn-primary" onClick={()=>handleVerify(u.id)}>{t('verify')}</button>
                      )}
                      <button className="btn btn-sm btn-ghost">{t('edit')}</button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-backdrop" onClick={()=>setShowModal(false)}>
          <motion.div className="modal-box" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} onClick={e=>e.stopPropagation()}>
            <div className="modal-head">
              <h3>{t('add_user')}</h3>
              <button className="modal-close-btn" onClick={()=>setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleAdd}>
              <div className="modal-body">
                {formErr && <div className="alert alert-danger" style={{marginBottom:16}}><AlertCircle size={16}/><span>{formErr}</span></div>}
                <div className="form-grid form-grid-2">
                  <div className="input-group" style={{gridColumn:'1/-1'}}>
                    <label className="input-label required">{t('full_name')}</label>
                    <input className="input" value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} required/>
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('email')}</label>
                    <input type="email" className="input" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/>
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('role')}</label>
                    <select className="input" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
                      <option value="doctor">{t('doctor')}</option>
                      <option value="receptionist">{t('receptionist')}</option>
                      <option value="lab_tech">{t('lab_tech')}</option>
                      <option value="pharmacist">{t('pharmacist')}</option>
                      <option value="admin">{t('admin')}</option>
                    </select>
                  </div>
                  <div className="input-group" style={{gridColumn:'1/-1'}}>
                    <label className="input-label required">{t('password')}</label>
                    <div className="input-wrapper">
                      <input
                        type={showPass?'text':'password'}
                        className="input"
                        style={{paddingInlineEnd:44}}
                        value={form.password}
                        onChange={e=>setForm({...form,password:e.target.value})}
                        required minLength={6}
                      />
                      <button type="button" className="input-action" onClick={()=>setShowPass(v=>!v)}>
                        {showPass ? <EyeOff size={16}/> : <Eye size={16}/>}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="modal-foot">
                <button type="button" className="btn btn-secondary" onClick={()=>setShowModal(false)}>{t('cancel')}</button>
                <button type="submit" className={`btn btn-primary ${saving?'btn-loading':''}`} disabled={saving}>{!saving&&t('save')}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  )
}
