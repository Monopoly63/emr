import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Users, Calendar, Pill, Activity, FlaskConical,
  Clock, CheckCircle, AlertCircle, ArrowRight, RefreshCw
} from 'lucide-react'
import { useAuth }     from '../../context/AuthContext'
import { useLanguage } from '../../context/LanguageContext'
import { reportsAPI, appointmentsAPI, prescriptionsAPI } from '../../api'
import './Dashboard.css'

const STATUS_BADGE = {
  confirmed:   'badge-success',
  scheduled:   'badge-primary',
  cancelled:   'badge-danger',
  in_progress: 'badge-warning',
  pending:     'badge-warning',
  dispensed:   'badge-success',
}

export default function Dashboard() {
  const { user } = useAuth()
  const { t }    = useLanguage()

  const [stats,  setStats]  = useState(null)
  const [appts,  setAppts]  = useState([])
  const [rxs,    setRxs]    = useState([])
  const [loading, setLoading] = useState(true)
  const [error,  setError]  = useState('')

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const [statsRes, apptsRes, rxRes] = await Promise.all([
        reportsAPI.dashboard().catch(() => null),
        appointmentsAPI.list({ limit: 5, status: 'scheduled,confirmed' }).catch(() => null),
        prescriptionsAPI.list({ limit: 5, status: 'pending' }).catch(() => null),
      ])

      if (statsRes)  setStats(statsRes.data)
      if (apptsRes)  setAppts(apptsRes.data?.appointments || apptsRes.data || [])
      if (rxRes)     setRxs(rxRes.data?.prescriptions   || rxRes.data || [])
    } catch {
      setError(t('operation_failed'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const statCards = [
    {
      label: t('total_patients'),
      value: stats?.total_patients ?? '—',
      icon: Users,
      color: 'primary',
      link: '/patients',
    },
    {
      label: t('today_appointments'),
      value: stats?.today_appointments ?? '—',
      icon: Calendar,
      color: 'teal',
      link: '/appointments',
    },
    {
      label: t('pending_prescriptions'),
      value: stats?.pending_prescriptions ?? '—',
      icon: Pill,
      color: 'warning',
      link: '/prescriptions',
    },
    {
      label: t('completed_visits'),
      value: stats?.completed_visits ?? '—',
      icon: Activity,
      color: 'success',
      link: '/visits',
    },
  ]

  if (loading) {
    return (
      <div className="spinner-center">
        <div className="spinner" />
      </div>
    )
  }

  return (
    <motion.div
      className="dashboard"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* ── Welcome ────────────────────────────── */}
      <div className="dash-welcome">
        <div>
          <h1 className="dash-welcome-title">
            {t('welcome_back')}, {user?.full_name?.split(' ')[0]} 👋
          </h1>
          <p className="dash-welcome-sub">
            {new Date().toLocaleDateString(
              user?.role === 'doctor' ? 'ar-SY' : 'en-US',
              { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
            )}
          </p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={load} title={t('refresh')}>
          <RefreshCw size={16} />
          {t('refresh')}
        </button>
      </div>

      {error && (
        <div className="alert alert-warning" style={{ marginBottom: 16 }}>
          <AlertCircle size={16} />
          <span>{error} — {t('showing_cached_data')}</span>
        </div>
      )}

      {/* ── Stats ──────────────────────────────── */}
      <div className="stats-grid">
        {statCards.map((card, i) => {
          const Icon = card.icon
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * .07 }}
            >
              <Link to={card.link} className="stat-card" style={{ display: 'flex', textDecoration: 'none' }}>
                <div className={`stat-icon-wrap ${card.color}`}>
                  <Icon size={22} />
                </div>
                <div className="stat-body">
                  <span className="stat-value">{card.value?.toLocaleString?.() ?? card.value}</span>
                  <span className="stat-label">{card.label}</span>
                </div>
                <ArrowRight size={16} style={{ color: 'var(--c-text-4)', marginTop: 4 }} />
              </Link>
            </motion.div>
          )
        })}
      </div>

      {/* ── Grid ───────────────────────────────── */}
      <div className="dash-grid">

        {/* Today's Appointments */}
        <motion.div
          className="card"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: .28 }}
        >
          <div className="card-header">
            <h3><Calendar size={18} /> {t('today_appointments')}</h3>
            <Link to="/appointments" className="btn btn-ghost btn-sm">
              {t('view_all')} <ArrowRight size={14} />
            </Link>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            {appts.length === 0 ? (
              <div className="empty-state" style={{ padding: 32 }}>
                <Calendar size={32} />
                <p>{t('no_appointments_today')}</p>
              </div>
            ) : (
              appts.slice(0, 5).map(a => (
                <div key={a.id} className="dash-list-item">
                  <div className="avatar avatar-sm">
                    {(a.patient_name || a.patient || '?').charAt(0).toUpperCase()}
                  </div>
                  <div className="dash-list-info">
                    <p className="dash-list-name">{a.patient_name || a.patient}</p>
                    <p className="dash-list-sub">
                      <Clock size={12} /> {a.appointment_date ? new Date(a.appointment_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : a.time}
                    </p>
                  </div>
                  <span className={`badge ${STATUS_BADGE[a.status] || 'badge-neutral'}`}>
                    {t(a.status)}
                  </span>
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Pending Prescriptions */}
        <motion.div
          className="card"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: .35 }}
        >
          <div className="card-header">
            <h3><Pill size={18} /> {t('pending_prescriptions')}</h3>
            <Link to="/prescriptions" className="btn btn-ghost btn-sm">
              {t('view_all')} <ArrowRight size={14} />
            </Link>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            {rxs.length === 0 ? (
              <div className="empty-state" style={{ padding: 32 }}>
                <CheckCircle size={32} />
                <p>{t('no_pending_prescriptions')}</p>
              </div>
            ) : (
              rxs.slice(0, 5).map(rx => (
                <div key={rx.id} className="dash-list-item">
                  <div className={`stat-icon-wrap warning`} style={{ width: 36, height: 36 }}>
                    <Pill size={16} />
                  </div>
                  <div className="dash-list-info">
                    <p className="dash-list-name">{rx.medication_name || rx.medication}</p>
                    <p className="dash-list-sub">{rx.patient_name || rx.patient}</p>
                  </div>
                  <span className={`badge ${STATUS_BADGE[rx.status] || 'badge-neutral'}`}>
                    {t(rx.status)}
                  </span>
                </div>
              ))
            )}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          className="card"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: .42 }}
        >
          <div className="card-header">
            <h3>{t('quick_actions')}</h3>
          </div>
          <div className="card-body">
            <div className="dash-quick-actions">
              {[
                { label: t('new_patient'),      to: '/patients',      icon: Users,        color: 'primary' },
                { label: t('new_visit'),         to: '/visits',        icon: Activity,     color: 'teal' },
                { label: t('book_appointment'), to: '/appointments',  icon: Calendar,     color: 'success' },
                { label: t('lab_requests'),     to: '/lab-requests',  icon: FlaskConical, color: 'warning' },
              ].map(action => {
                const Icon = action.icon
                return (
                  <Link key={action.label} to={action.to} className="dash-quick-btn">
                    <div className={`stat-icon-wrap ${action.color}`} style={{ width: 40, height: 40 }}>
                      <Icon size={18} />
                    </div>
                    <span>{action.label}</span>
                  </Link>
                )
              })}
            </div>
          </div>
        </motion.div>

      </div>
    </motion.div>
  )
}
