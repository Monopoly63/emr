import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Activity, Plus, Clock, CheckCircle, Search, X, AlertCircle } from 'lucide-react'
import { useLanguage } from '../../context/LanguageContext'
import { useAuth }     from '../../context/AuthContext'
import { visitsAPI, patientsAPI } from '../../api'

const STATUS_MAP = {
  scheduled:   'badge-primary',
  in_progress: 'badge-warning',
  completed:   'badge-success',
  cancelled:   'badge-danger',
}

export default function Visits() {
  const { t }    = useLanguage()
  const { user } = useAuth()

  const [visits,  setVisits]   = useState([])
  const [loading, setLoading]  = useState(true)
  const [error,   setError]    = useState('')
  const [filter,  setFilter]   = useState('all')
  const [showModal, setShowModal] = useState(false)
  const [saving,  setSaving]   = useState(false)
  const [formErr, setFormErr]  = useState('')
  const [patients, setPatients] = useState([])

  const emptyForm = { patient_id:'', complaint:'', notes:'', doctor_id: user?.id || '' }
  const [form, setForm] = useState(emptyForm)

  // ── Fetch Visits ───────────────────────────────────────────
  const fetchVisits = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await visitsAPI.list(params)
      setVisits(res.data?.visits || res.data || [])
    } catch (e) {
      setError(e.response?.data?.error || t('operation_failed'))
    } finally { setLoading(false) }
  }, [filter])

  useEffect(() => { fetchVisits() }, [fetchVisits])

  // Fetch patients for dropdown
  useEffect(() => {
    patientsAPI.list({ limit: 100 })
      .then(r => setPatients(r.data?.patients || r.data || []))
      .catch(() => {})
  }, [])

  // ── Status actions ─────────────────────────────────────────
  const updateStatus = async (id, status) => {
    try {
      await visitsAPI.update(id, { status })
      fetchVisits()
    } catch { setError(t('operation_failed')) }
  }

  // ── Add Visit ─────────────────────────────────────────────
  const handleAdd = async (e) => {
    e.preventDefault(); setFormErr(''); setSaving(true)
    try {
      await visitsAPI.create(form)
      setShowModal(false); setForm(emptyForm); fetchVisits()
    } catch (err) {
      setFormErr(err.response?.data?.error || err.response?.data?.errors?.[0]?.msg || t('operation_failed'))
    } finally { setSaving(false) }
  }

  const counts = {
    all:         visits.length,
    scheduled:   visits.filter(v => v.status === 'scheduled').length,
    in_progress: visits.filter(v => v.status === 'in_progress').length,
    completed:   visits.filter(v => v.status === 'completed').length,
  }

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title"><Activity size={24} /> {t('visits')}</h1>
          <p className="page-subtitle">{t('visits_subtitle')}</p>
        </div>
        {['admin','doctor','receptionist'].includes(user?.role) && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={18} /> {t('new_visit')}
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="filter-tabs">
        {Object.entries(counts).map(([key, count]) => (
          <button
            key={key}
            className={`filter-tab ${filter === key ? 'active' : ''}`}
            onClick={() => setFilter(key)}
          >
            {t(key === 'all' ? 'all' : key)} <span className="filter-count">{count}</span>
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger"><AlertCircle size={16} /><span>{error}</span></div>}

      {/* Visits Table */}
      {loading ? (
        <div className="spinner-center"><div className="spinner" /></div>
      ) : visits.length === 0 ? (
        <div className="empty-state">
          <Activity size={48} />
          <h3>{t('no_visits_found')}</h3>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>{t('patient')}</th>
                <th>{t('complaint')}</th>
                <th>{t('diagnosis')}</th>
                <th>{t('doctor')}</th>
                <th>{t('date')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {visits.map((v, i) => (
                <motion.tr key={v.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * .03 }}>
                  <td>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div className="avatar avatar-sm">{(v.patient_name||'P').charAt(0).toUpperCase()}</div>
                      <span style={{ fontWeight:500 }}>{v.patient_name || '—'}</span>
                    </div>
                  </td>
                  <td>{v.complaint}</td>
                  <td>{v.diagnosis || <span style={{ color:'var(--c-text-4)' }}>—</span>}</td>
                  <td>{v.doctor_name || '—'}</td>
                  <td style={{ whiteSpace:'nowrap' }}>{v.created_at ? new Date(v.created_at).toLocaleDateString() : '—'}</td>
                  <td><span className={`badge ${STATUS_MAP[v.status] || 'badge-neutral'}`}>{t(v.status)}</span></td>
                  <td>
                    <div style={{ display:'flex', gap:6 }}>
                      {v.status === 'scheduled' && (
                        <button className="btn btn-sm btn-primary" onClick={() => updateStatus(v.id, 'in_progress')}>
                          {t('start_visit')}
                        </button>
                      )}
                      {v.status === 'in_progress' && (
                        <button className="btn btn-sm btn-success" onClick={() => updateStatus(v.id, 'completed')}>
                          {t('complete_visit')}
                        </button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Visit Modal */}
      {showModal && (
        <div className="modal-backdrop" onClick={() => setShowModal(false)}>
          <motion.div className="modal-box" initial={{ opacity:0, scale:.96 }} animate={{ opacity:1, scale:1 }} onClick={e=>e.stopPropagation()}>
            <div className="modal-head">
              <h3>{t('new_visit')}</h3>
              <button className="modal-close-btn" onClick={() => setShowModal(false)}><X size={18}/></button>
            </div>
            <form onSubmit={handleAdd}>
              <div className="modal-body">
                {formErr && <div className="alert alert-danger" style={{marginBottom:16}}><AlertCircle size={16}/><span>{formErr}</span></div>}
                <div className="form-grid">
                  <div className="input-group">
                    <label className="input-label required">{t('patient')}</label>
                    <select className="input" value={form.patient_id} onChange={e=>setForm({...form,patient_id:e.target.value})} required>
                      <option value="">{t('select_patient')}</option>
                      {patients.map(p=><option key={p.id} value={p.id}>{p.full_name} — #{p.national_id}</option>)}
                    </select>
                  </div>
                  <div className="input-group">
                    <label className="input-label required">{t('complaint')}</label>
                    <textarea className="input" rows={3} value={form.complaint} onChange={e=>setForm({...form,complaint:e.target.value})} required/>
                  </div>
                  <div className="input-group">
                    <label className="input-label">{t('notes')}</label>
                    <textarea className="input" rows={2} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
                  </div>
                </div>
              </div>
              <div className="modal-foot">
                <button type="button" className="btn btn-secondary" onClick={()=>setShowModal(false)}>{t('cancel')}</button>
                <button type="submit" className={`btn btn-primary ${saving?'btn-loading':''}`} disabled={saving}>{!saving&&t('save')}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  )
}
