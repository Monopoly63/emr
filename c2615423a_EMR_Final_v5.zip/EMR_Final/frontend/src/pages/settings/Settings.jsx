import { useState } from 'react'
import { motion } from 'framer-motion'
import { Settings as SettingsIcon, User, Palette, Globe, Bell, Shield, Moon, Sun, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react'
import { useLanguage } from '../../context/LanguageContext'
import { useTheme }    from '../../context/ThemeContext'
import { useAuth }     from '../../context/AuthContext'
import { authAPI }     from '../../api'
import './Settings.css'

export default function Settings() {
  const { t, language, toggleLanguage } = useLanguage()
  const { isDark, toggleTheme }         = useTheme()
  const { user }                        = useAuth()

  const [pwForm, setPwForm] = useState({ current_password:'', new_password:'', confirm:'' })
  const [showPw,  setShowPw]  = useState(false)
  const [pwSaving, setPwSaving] = useState(false)
  const [pwMsg,   setPwMsg]   = useState(null)  // { type: 'success'|'error', text }

  const handlePwSubmit = async (e) => {
    e.preventDefault()
    if (pwForm.new_password !== pwForm.confirm) {
      setPwMsg({ type:'error', text: t('passwords_mismatch') }); return
    }
    if (pwForm.new_password.length < 6) {
      setPwMsg({ type:'error', text: t('password_min_length') }); return
    }
    setPwSaving(true); setPwMsg(null)
    try {
      await authAPI.changePassword({
        current_password: pwForm.current_password,
        new_password: pwForm.new_password,
      })
      setPwMsg({ type:'success', text: t('change_password') + ' ✓' })
      setPwForm({ current_password:'', new_password:'', confirm:'' })
    } catch (err) {
      setPwMsg({ type:'error', text: err.response?.data?.error || t('operation_failed') })
    } finally { setPwSaving(false) }
  }

  return (
    <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }}>
      <div className="page-header">
        <div>
          <h1 className="page-title"><SettingsIcon size={24}/> {t('settings')}</h1>
          <p className="page-subtitle">{t('profile')} • {t('appearance')} • {t('security')}</p>
        </div>
      </div>

      <div className="settings-grid">

        {/* ── Profile ─────────────────────────── */}
        <div className="card">
          <div className="card-header"><h3><User size={18}/> {t('profile')}</h3></div>
          <div className="card-body">
            <div style={{ display:'flex', alignItems:'center', gap:'var(--sp-4)', marginBottom:'var(--sp-5)' }}>
              <div className="avatar avatar-xl">{user?.full_name?.charAt(0)?.toUpperCase()||'U'}</div>
              <div>
                <p style={{ fontWeight:700, fontSize:'1.125rem', color:'var(--c-text)' }}>{user?.full_name}</p>
                <p style={{ color:'var(--c-text-3)', fontSize:'.9rem' }}>{user?.email}</p>
                <span className="badge badge-primary" style={{ marginTop:6 }}>{t(user?.role)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── Appearance ──────────────────────── */}
        <div className="card">
          <div className="card-header"><h3><Palette size={18}/> {t('appearance')}</h3></div>
          <div className="card-body">
            <p className="text-muted" style={{ marginBottom:'var(--sp-4)' }}>{t('light_theme')} / {t('dark_theme')}</p>
            <div className="theme-options">
              <button
                className={`theme-opt ${!isDark ? 'active' : ''}`}
                onClick={() => isDark && toggleTheme()}
              >
                <Sun size={20}/>
                <span>{t('light_theme')}</span>
              </button>
              <button
                className={`theme-opt ${isDark ? 'active' : ''}`}
                onClick={() => !isDark && toggleTheme()}
              >
                <Moon size={20}/>
                <span>{t('dark_theme')}</span>
              </button>
            </div>
          </div>
        </div>

        {/* ── Language ────────────────────────── */}
        <div className="card">
          <div className="card-header"><h3><Globe size={18}/> {t('language')}</h3></div>
          <div className="card-body">
            <div className="theme-options">
              <button
                className={`theme-opt ${language==='en' ? 'active' : ''}`}
                onClick={() => language!=='en' && toggleLanguage()}
              >
                <span style={{ fontSize:'1.25rem' }}>🇺🇸</span>
                <span>{t('english')}</span>
              </button>
              <button
                className={`theme-opt ${language==='ar' ? 'active' : ''}`}
                onClick={() => language!=='ar' && toggleLanguage()}
              >
                <span style={{ fontSize:'1.25rem' }}>🇸🇾</span>
                <span>{t('arabic')}</span>
              </button>
            </div>
          </div>
        </div>

        {/* ── Change Password ──────────────────── */}
        <div className="card">
          <div className="card-header"><h3><Shield size={18}/> {t('change_password')}</h3></div>
          <div className="card-body">
            {pwMsg && (
              <div className={`alert alert-${pwMsg.type==='success'?'success':'danger'}`} style={{ marginBottom:'var(--sp-4)' }}>
                {pwMsg.type==='success' ? <CheckCircle size={16}/> : <AlertCircle size={16}/>}
                <span>{pwMsg.text}</span>
              </div>
            )}
            <form onSubmit={handlePwSubmit} className="form-grid">
              <div className="input-group">
                <label className="input-label required">{t('password')} ({t('security')})</label>
                <div className="input-wrapper">
                  <input
                    type={showPw?'text':'password'}
                    className="input"
                    style={{ paddingInlineEnd:44 }}
                    placeholder="••••••••"
                    value={pwForm.current_password}
                    onChange={e=>setPwForm({...pwForm,current_password:e.target.value})}
                    required
                  />
                  <button type="button" className="input-action" onClick={()=>setShowPw(v=>!v)}>
                    {showPw?<EyeOff size={16}/>:<Eye size={16}/>}
                  </button>
                </div>
              </div>
              <div className="input-group">
                <label className="input-label required">{t('password')} ({t('next')})</label>
                <input
                  type={showPw?'text':'password'}
                  className="input"
                  placeholder="••••••••"
                  value={pwForm.new_password}
                  onChange={e=>setPwForm({...pwForm,new_password:e.target.value})}
                  required minLength={6}
                />
              </div>
              <div className="input-group">
                <label className="input-label required">{t('confirm_password')}</label>
                <input
                  type={showPw?'text':'password'}
                  className="input"
                  placeholder="••••••••"
                  value={pwForm.confirm}
                  onChange={e=>setPwForm({...pwForm,confirm:e.target.value})}
                  required
                />
              </div>
              <button
                type="submit"
                className={`btn btn-primary ${pwSaving?'btn-loading':''}`}
                disabled={pwSaving}
                style={{ marginTop:'var(--sp-2)' }}
              >
                {!pwSaving && t('save')}
              </button>
            </form>
          </div>
        </div>

      </div>
    </motion.div>
  )
}
