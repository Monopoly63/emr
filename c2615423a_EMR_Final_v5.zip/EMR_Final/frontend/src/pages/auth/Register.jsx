import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, Lock, Eye, EyeOff, User, Phone, Calendar, Stethoscope, AlertCircle } from 'lucide-react'
import { useAuth }     from '../../context/AuthContext'
import { useLanguage } from '../../context/LanguageContext'
import './Auth.css'

export default function Register() {
  const { register } = useAuth()
  const { t }        = useLanguage()
  const navigate     = useNavigate()

  const [form, setForm] = useState({
    national_id: '', full_name: '', email: '',
    phone: '', date_of_birth: '', gender: 'male',
    password: '', confirm_password: '',
  })
  const [showPass, setShowPass]   = useState(false)
  const [loading, setLoading]     = useState(false)
  const [error, setError]         = useState('')

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    if (error) setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (form.password !== form.confirm_password) {
      setError(t('passwords_mismatch'))
      return
    }
    if (form.password.length < 6) {
      setError(t('password_min_length'))
      return
    }
    setLoading(true)
    const { confirm_password, ...payload } = form
    const res = await register(payload)
    setLoading(false)
    if (res.success) {
      navigate('/dashboard', { replace: true })
    } else {
      setError(res.error)
    }
  }

  return (
    <div className="auth-page">
      {/* Left panel */}
      <div className="auth-panel-left">
        <div className="auth-brand">
          <div className="auth-brand-icon">
            <Stethoscope size={32} />
          </div>
          <h1>{t('app_name')}</h1>
          <p>{t('auth_tagline')}</p>
        </div>
        <div className="auth-features">
          {['auth_feat_1', 'auth_feat_2', 'auth_feat_3'].map(k => (
            <div key={k} className="auth-feature-item">
              <span className="auth-feature-dot" />
              <span>{t(k)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="auth-panel-right">
        <motion.div
          className="auth-card auth-card-wide"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: .35 }}
        >
          <div className="auth-card-head">
            <h2>{t('register')}</h2>
            <p>{t('register_subtitle')}</p>
          </div>

          {error && (
            <div className="alert alert-danger">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="auth-form" noValidate>
            <div className="form-grid form-grid-2">
              {/* National ID */}
              <div className="input-group">
                <label className="input-label required" htmlFor="national_id">{t('national_id')}</label>
                <div className="input-wrapper">
                  <User size={16} className="input-icon" />
                  <input id="national_id" name="national_id" className="input" value={form.national_id} onChange={handleChange} required />
                </div>
              </div>

              {/* Full Name */}
              <div className="input-group">
                <label className="input-label required" htmlFor="full_name">{t('full_name')}</label>
                <div className="input-wrapper">
                  <User size={16} className="input-icon" />
                  <input id="full_name" name="full_name" className="input" value={form.full_name} onChange={handleChange} required />
                </div>
              </div>

              {/* Email */}
              <div className="input-group">
                <label className="input-label required" htmlFor="reg_email">{t('email')}</label>
                <div className="input-wrapper">
                  <Mail size={16} className="input-icon" />
                  <input id="reg_email" name="email" type="email" className="input" value={form.email} onChange={handleChange} required autoComplete="email" />
                </div>
              </div>

              {/* Phone */}
              <div className="input-group">
                <label className="input-label" htmlFor="phone">{t('phone')}</label>
                <div className="input-wrapper">
                  <Phone size={16} className="input-icon" />
                  <input id="phone" name="phone" type="tel" className="input" value={form.phone} onChange={handleChange} />
                </div>
              </div>

              {/* DOB */}
              <div className="input-group">
                <label className="input-label" htmlFor="date_of_birth">{t('date_of_birth')}</label>
                <div className="input-wrapper">
                  <Calendar size={16} className="input-icon" />
                  <input id="date_of_birth" name="date_of_birth" type="date" className="input" value={form.date_of_birth} onChange={handleChange} />
                </div>
              </div>

              {/* Gender */}
              <div className="input-group">
                <label className="input-label" htmlFor="gender">{t('gender')}</label>
                <select id="gender" name="gender" className="input" value={form.gender} onChange={handleChange}>
                  <option value="male">{t('male')}</option>
                  <option value="female">{t('female')}</option>
                </select>
              </div>

              {/* Password */}
              <div className="input-group">
                <label className="input-label required" htmlFor="reg_pass">{t('password')}</label>
                <div className="input-wrapper">
                  <Lock size={16} className="input-icon" />
                  <input
                    id="reg_pass" name="password"
                    type={showPass ? 'text' : 'password'}
                    className="input" style={{ paddingInlineEnd: 44 }}
                    value={form.password} onChange={handleChange}
                    required minLength={6} autoComplete="new-password"
                  />
                  <button type="button" className="input-action" onClick={() => setShowPass(v => !v)}>
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {/* Confirm */}
              <div className="input-group">
                <label className="input-label required" htmlFor="confirm_pass">{t('confirm_password')}</label>
                <div className="input-wrapper">
                  <Lock size={16} className="input-icon" />
                  <input
                    id="confirm_pass" name="confirm_password"
                    type={showPass ? 'text' : 'password'}
                    className="input"
                    value={form.confirm_password} onChange={handleChange}
                    required autoComplete="new-password"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className={`btn btn-primary btn-full btn-lg ${loading ? 'btn-loading' : ''}`}
              disabled={loading}
              style={{ marginTop: 8 }}
            >
              {!loading && t('sign_up')}
            </button>
          </form>

          <p className="auth-switch">
            {t('already_have_account')}{' '}
            <Link to="/login">{t('login')}</Link>
          </p>
        </motion.div>
      </div>
    </div>
  )
}
