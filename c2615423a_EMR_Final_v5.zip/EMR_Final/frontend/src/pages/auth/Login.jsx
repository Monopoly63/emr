import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, Lock, Eye, EyeOff, Stethoscope, AlertCircle } from 'lucide-react'
import { useAuth }     from '../../context/AuthContext'
import { useLanguage } from '../../context/LanguageContext'
import { useTheme }    from '../../context/ThemeContext'
import './Auth.css'

export default function Login() {
  const { login }  = useAuth()
  const { t }      = useLanguage()
  const { isDark, toggleTheme } = useTheme()
  const navigate   = useNavigate()

  const [form, setForm]       = useState({ email: '', password: '' })
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    if (error) setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.email || !form.password) {
      setError(t('fill_all_fields'))
      return
    }
    setLoading(true)
    const res = await login(form.email, form.password)
    setLoading(false)
    if (res.success) {
      navigate('/dashboard', { replace: true })
    } else {
      setError(res.error)
    }
  }

  return (
    <div className="auth-page">
      {/* ── Left Panel ─────────────────────────── */}
      <div className="auth-panel-left">
        <div className="auth-brand">
          <div className="auth-brand-icon">
            <Stethoscope size={32} />
          </div>
          <h1>{t('app_name')}</h1>
          <p>{t('auth_tagline')}</p>
        </div>
        <div className="auth-features">
          {['auth_feat_1', 'auth_feat_2', 'auth_feat_3'].map(k => (
            <div key={k} className="auth-feature-item">
              <span className="auth-feature-dot" />
              <span>{t(k)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Right Panel ────────────────────────── */}
      <div className="auth-panel-right">
        <div className="auth-theme-toggle">
          <button className="btn btn-ghost btn-sm" onClick={toggleTheme} title={isDark ? t('light_theme') : t('dark_theme')}>
            {isDark ? '☀️' : '🌙'}
          </button>
        </div>

        <motion.div
          className="auth-card"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: .35 }}
        >
          <div className="auth-card-head">
            <h2>{t('login')}</h2>
            <p>{t('login_subtitle')}</p>
          </div>

          {error && (
            <div className="alert alert-danger">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="auth-form" noValidate>
            {/* Email */}
            <div className="input-group">
              <label className="input-label required" htmlFor="email">{t('email')}</label>
              <div className="input-wrapper">
                <Mail size={16} className="input-icon" />
                <input
                  id="email"
                  name="email"
                  type="email"
                  className="input"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="doctor@hospital.com"
                  autoComplete="email"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div className="input-group">
              <label className="input-label required" htmlFor="password">{t('password')}</label>
              <div className="input-wrapper">
                <Lock size={16} className="input-icon" />
                <input
                  id="password"
                  name="password"
                  type={showPass ? 'text' : 'password'}
                  className="input"
                  style={{ paddingInlineEnd: 44 }}
                  value={form.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  required
                />
                <button
                  type="button"
                  className="input-action"
                  onClick={() => setShowPass(v => !v)}
                  aria-label="Toggle password"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className={`btn btn-primary btn-full btn-lg ${loading ? 'btn-loading' : ''}`}
              disabled={loading}
            >
              {!loading && t('login')}
            </button>
          </form>

          <p className="auth-switch">
            {t('dont_have_account')}{' '}
            <Link to="/register">{t('sign_up')}</Link>
          </p>
        </motion.div>
      </div>
    </div>
  )
}
