/**
 * useApi — hook موحد لكل العمليات
 * يتعامل مع loading / error / data تلقائياً
 */
import { useState, useCallback } from 'react'

export function useApi() {
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState(null)

  const execute = useCallback(async (apiCall, options = {}) => {
    setLoading(true)
    setError(null)
    try {
      const res = await apiCall()
      options.onSuccess?.(res.data)
      return { success: true, data: res.data }
    } catch (err) {
      const msg =
        err.response?.data?.error ||
        err.response?.data?.errors?.[0]?.msg ||
        err.message ||
        'حدث خطأ غير متوقع'
      setError(msg)
      options.onError?.(msg)
      return { success: false, error: msg }
    } finally {
      setLoading(false)
    }
  }, [])

  return { loading, error, execute, setError }
}

/**
 * useFetch — hook لجلب البيانات عند mount
 */
import { useEffect, useRef } from 'react'

export function useFetch(apiCall, deps = []) {
  const [data, setData]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError]   = useState(null)
  const mounted = useRef(true)

  const fetch = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await apiCall()
      if (mounted.current) setData(res.data)
    } catch (err) {
      if (mounted.current) {
        setError(
          err.response?.data?.error ||
          err.message ||
          'فشل تحميل البيانات'
        )
      }
    } finally {
      if (mounted.current) setLoading(false)
    }
  }, deps)

  useEffect(() => {
    mounted.current = true
    fetch()
    return () => { mounted.current = false }
  }, [fetch])

  return { data, loading, error, refetch: fetch }
}
