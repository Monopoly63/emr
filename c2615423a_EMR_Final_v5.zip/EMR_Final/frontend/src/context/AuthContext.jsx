import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { authAPI } from '../api'

const AuthContext = createContext()

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}

export const AuthProvider = ({ children }) => {
  const [user,    setUser]    = useState(null)
  const [loading, setLoading] = useState(true)
  const [token,   setToken]   = useState(() => localStorage.getItem('emr-token'))

  // ── Re-hydrate session on mount ──────────────────────────
  useEffect(() => {
    if (!token) { setLoading(false); return }
    authAPI.me()
      .then(res => setUser(res.data))
      .catch(() => {
        localStorage.removeItem('emr-token')
        localStorage.removeItem('emr-refresh-token')
        setToken(null)
      })
      .finally(() => setLoading(false))
  }, [])

  // ── Login ────────────────────────────────────────────────
  const login = async (email, password) => {
    try {
      const res = await authAPI.login({ email, password })
      const { accessToken, refreshToken, user: userData } = res.data
      localStorage.setItem('emr-token', accessToken)
      if (refreshToken) localStorage.setItem('emr-refresh-token', refreshToken)
      setToken(accessToken)
      setUser(userData)
      return { success: true, user: userData }
    } catch (err) {
      return {
        success: false,
        error: err.response?.data?.error
          || err.response?.data?.errors?.[0]?.msg
          || 'فشل تسجيل الدخول. تحقق من بيانات الاعتماد.',
      }
    }
  }

  // ── Register ─────────────────────────────────────────────
  const register = async (userData) => {
    try {
      const res  = await authAPI.register(userData)
      const newToken = res.data.accessToken || res.data.token
      const newUser  = res.data.user
      localStorage.setItem('emr-token', newToken)
      setToken(newToken)
      setUser(newUser)
      return { success: true, user: newUser }
    } catch (err) {
      return {
        success: false,
        error: err.response?.data?.error
          || err.response?.data?.errors?.[0]?.msg
          || 'فشل إنشاء الحساب. حاول مجدداً.',
      }
    }
  }

  // ── Logout ───────────────────────────────────────────────
  const logout = useCallback(async () => {
    try {
      const refreshToken = localStorage.getItem('emr-refresh-token')
      await authAPI.logout({ refreshToken })
    } catch { /* ignore */ } finally {
      localStorage.removeItem('emr-token')
      localStorage.removeItem('emr-refresh-token')
      setToken(null)
      setUser(null)
    }
  }, [])

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}
