import { createContext, useContext, useState, useEffect } from 'react'

const LanguageContext = createContext()

const translations = {
  en: {
    // App
    app_name: 'MediCore EMR',
    auth_tagline: 'Secure, local electronic medical records for your clinic.',
    auth_feat_1: 'Full patient history & records',
    auth_feat_2: 'Role-based access control',
    auth_feat_3: 'Offline-ready, runs on your server',

    // Nav
    dashboard:     'Dashboard',
    patients:      'Patients',
    visits:        'Visits',
    appointments:  'Appointments',
    prescriptions: 'Prescriptions',
    lab_requests:  'Lab Requests',
    users:         'Users',
    settings:      'Settings',

    // Auth
    login:               'Sign In',
    login_subtitle:      'Enter your credentials to access the system.',
    register:            'Create Account',
    register_subtitle:   'Register as a new patient.',
    sign_up:             'Sign Up',
    logout:              'Logout',
    email:               'Email Address',
    password:            'Password',
    confirm_password:    'Confirm Password',
    dont_have_account:   "Don't have an account?",
    already_have_account:'Already have an account?',
    fill_all_fields:     'Please fill in all required fields.',
    passwords_mismatch:  'Passwords do not match.',
    password_min_length: 'Password must be at least 6 characters.',

    // Dashboard
    welcome_back:           'Welcome back',
    total_patients:         'Total Patients',
    today_appointments:     "Today's Appointments",
    pending_prescriptions:  'Pending Prescriptions',
    completed_visits:       'Completed Visits',
    quick_actions:          'Quick Actions',
    view_all:               'View All',
    refresh:                'Refresh',
    no_appointments_today:  'No appointments today.',
    no_pending_prescriptions:'All prescriptions dispensed.',
    showing_cached_data:    'Showing cached data',

    // Patients
    patients_subtitle:   'Manage and view all patient records.',
    add_patient:         'Add Patient',
    new_patient:         'New Patient',
    patient_details:     'View Record',
    no_patients_found:   'No patients found.',
    try_different_search:'Try a different search term.',
    by_name_id_phone:    'by name, ID, or phone',
    national_id:         'National ID',
    full_name:           'Full Name',
    date_of_birth:       'Date of Birth',
    gender:              'Gender',
    male:                'Male',
    female:              'Female',
    phone:               'Phone',
    address:             'Address',
    blood_type:          'Blood Type',
    allergies:           'Allergies',
    select_patient:      'Select patient...',

    // Visits
    visits_subtitle:  'Manage patient visits and consultations.',
    new_visit:        'New Visit',
    no_visits_found:  'No visits found.',
    complaint:        'Chief Complaint',
    diagnosis:        'Diagnosis',
    notes:            'Notes',
    start_visit:      'Start',
    complete_visit:   'Complete',
    select_doctor:    'Select doctor...',

    // Appointments
    appointments_subtitle: 'Schedule and manage appointments.',
    book_appointment:      'Book Appointment',
    no_appointments_found: 'No appointments found.',
    doctor:                'Doctor',
    date_time:             'Date & Time',
    confirm:               'Confirm',

    // Prescriptions
    prescriptions_subtitle: 'Manage and dispense prescriptions.',
    new_prescription:       'New Prescription',
    no_prescriptions_found: 'No prescriptions found.',
    medication:             'Medication',
    dosage:                 'Dosage',
    duration:               'Duration',
    days:                   'days',
    instructions:           'Instructions',
    dispense:               'Dispense',
    allergy_warning:        'Allergy Alert',

    // Lab
    lab_subtitle:        'Lab test requests and results.',
    new_request:         'New Request',
    no_lab_requests:     'No lab requests found.',
    test_type:           'Test Type',
    urgent:              'Urgency',
    urgency_level:       'Urgency Level',
    upload_results:      'Upload Results',
    routine:             'Routine',
    stat:                'STAT',

    // Users
    users_subtitle:       'Manage system users and permissions.',
    add_user:             'Add User',
    total_users:          'Total Users',
    pending_verification: 'Pending Verification',
    role:                 'Role',
    verified:             'Verified',
    verify:               'Verify',
    active:               'Active',
    inactive:             'Inactive',

    // Roles
    admin:         'Admin',
    doctor:        'Doctor',
    receptionist:  'Receptionist',
    lab_tech:      'Lab Technician',
    pharmacist:    'Pharmacist',
    patient:       'Patient',

    // Status
    all:         'All',
    scheduled:   'Scheduled',
    confirmed:   'Confirmed',
    in_progress: 'In Progress',
    completed:   'Completed',
    cancelled:   'Cancelled',
    pending:     'Pending',
    dispensed:   'Dispensed',
    no_show:     'No Show',

    // Settings
    profile:      'Profile',
    appearance:   'Appearance',
    language:     'Language',
    light_theme:  'Light Mode',
    dark_theme:   'Dark Mode',
    english:      'English',
    arabic:       'Arabic',
    security:     'Security',
    notifications:'Notifications',
    change_password: 'Change Password',

    // Shared
    search:       'Search',
    save:         'Save',
    cancel:       'Cancel',
    edit:         'Edit',
    delete:       'Delete',
    actions:      'Actions',
    status:       'Status',
    date:         'Date',
    time:         'Time',
    page:         'Page',
    of:           'of',
    prev:         'Prev',
    next:         'Next',
    collapse_menu:'Collapse menu',
    expand:       'Expand',
    operation_failed: 'Operation failed. Please try again.',
    no_data:      'No data available.',
  },

  ar: {
    // App
    app_name: 'ميديكور',
    auth_tagline: 'نظام سجلات طبية إلكترونية آمن ومحلي لعيادتك.',
    auth_feat_1: 'سجل المريض الكامل والتاريخ المرضي',
    auth_feat_2: 'صلاحيات متعددة بحسب الدور الوظيفي',
    auth_feat_3: 'يعمل بدون انترنت على سيرفرك',

    // Nav
    dashboard:     'لوحة التحكم',
    patients:      'المرضى',
    visits:        'الزيارات',
    appointments:  'المواعيد',
    prescriptions: 'الوصفات الطبية',
    lab_requests:  'طلبات المختبر',
    users:         'المستخدمون',
    settings:      'الإعدادات',

    // Auth
    login:               'تسجيل الدخول',
    login_subtitle:      'أدخل بيانات اعتماد حسابك للدخول إلى النظام.',
    register:            'إنشاء حساب',
    register_subtitle:   'سجّل كمريض جديد في النظام.',
    sign_up:             'إنشاء حساب',
    logout:              'تسجيل الخروج',
    email:               'البريد الإلكتروني',
    password:            'كلمة المرور',
    confirm_password:    'تأكيد كلمة المرور',
    dont_have_account:   'ليس لديك حساب؟',
    already_have_account:'لديك حساب بالفعل؟',
    fill_all_fields:     'يرجى تعبئة جميع الحقول المطلوبة.',
    passwords_mismatch:  'كلمتا المرور غير متطابقتين.',
    password_min_length: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.',

    // Dashboard
    welcome_back:           'أهلاً بعودتك',
    total_patients:         'إجمالي المرضى',
    today_appointments:     'مواعيد اليوم',
    pending_prescriptions:  'وصفات معلّقة',
    completed_visits:       'الزيارات المنجزة',
    quick_actions:          'إجراءات سريعة',
    view_all:               'عرض الكل',
    refresh:                'تحديث',
    no_appointments_today:  'لا مواعيد اليوم.',
    no_pending_prescriptions:'جميع الوصفات صُرِفت.',
    showing_cached_data:    'يُعرض آخر بيانات محفوظة',

    // Patients
    patients_subtitle:   'إدارة وعرض سجلات المرضى.',
    add_patient:         'إضافة مريض',
    new_patient:         'مريض جديد',
    patient_details:     'عرض السجل',
    no_patients_found:   'لا يوجد مرضى.',
    try_different_search:'جرّب مصطلح بحث آخر.',
    by_name_id_phone:    'بالاسم أو الهوية أو الهاتف',
    national_id:         'رقم الهوية',
    full_name:           'الاسم الكامل',
    date_of_birth:       'تاريخ الميلاد',
    gender:              'الجنس',
    male:                'ذكر',
    female:              'أنثى',
    phone:               'الهاتف',
    address:             'العنوان',
    blood_type:          'فصيلة الدم',
    allergies:           'الحساسية',
    select_patient:      'اختر المريض...',

    // Visits
    visits_subtitle:  'إدارة زيارات وفحوصات المرضى.',
    new_visit:        'زيارة جديدة',
    no_visits_found:  'لا توجد زيارات.',
    complaint:        'الشكوى الرئيسية',
    diagnosis:        'التشخيص',
    notes:            'ملاحظات',
    start_visit:      'بدء الزيارة',
    complete_visit:   'إنهاء الزيارة',
    select_doctor:    'اختر الطبيب...',

    // Appointments
    appointments_subtitle: 'جدولة وإدارة مواعيد المرضى.',
    book_appointment:      'حجز موعد',
    no_appointments_found: 'لا توجد مواعيد.',
    doctor:                'الطبيب',
    date_time:             'التاريخ والوقت',
    confirm:               'تأكيد',

    // Prescriptions
    prescriptions_subtitle: 'إدارة وصرف الوصفات الطبية.',
    new_prescription:       'وصفة جديدة',
    no_prescriptions_found: 'لا توجد وصفات.',
    medication:             'الدواء',
    dosage:                 'الجرعة',
    duration:               'المدة',
    days:                   'أيام',
    instructions:           'تعليمات الاستخدام',
    dispense:               'صرف الدواء',
    allergy_warning:        'تحذير حساسية',

    // Lab
    lab_subtitle:        'طلبات الفحوصات المخبرية ونتائجها.',
    new_request:         'طلب جديد',
    no_lab_requests:     'لا توجد طلبات مختبر.',
    test_type:           'نوع الفحص',
    urgent:              'الأولوية',
    urgency_level:       'مستوى الأولوية',
    upload_results:      'رفع النتائج',
    routine:             'عادي',
    stat:                'طارئ جداً',

    // Users
    users_subtitle:       'إدارة مستخدمي النظام والصلاحيات.',
    add_user:             'إضافة مستخدم',
    total_users:          'إجمالي المستخدمين',
    pending_verification: 'بانتظار التحقق',
    role:                 'الدور',
    verified:             'موثّق',
    verify:               'توثيق',
    active:               'نشط',
    inactive:             'غير نشط',

    // Roles
    admin:         'مدير النظام',
    doctor:        'طبيب',
    receptionist:  'موظف استقبال',
    lab_tech:      'فني مختبر',
    pharmacist:    'صيدلاني',
    patient:       'مريض',

    // Status
    all:         'الكل',
    scheduled:   'مجدول',
    confirmed:   'مؤكد',
    in_progress: 'جارٍ',
    completed:   'منجز',
    cancelled:   'ملغى',
    pending:     'معلّق',
    dispensed:   'مصروف',
    no_show:     'لم يحضر',

    // Settings
    profile:      'الملف الشخصي',
    appearance:   'المظهر',
    language:     'اللغة',
    light_theme:  'الوضع الفاتح',
    dark_theme:   'الوضع الداكن',
    english:      'الإنجليزية',
    arabic:       'العربية',
    security:     'الأمان',
    notifications:'الإشعارات',
    change_password: 'تغيير كلمة المرور',

    // Shared
    search:       'بحث',
    save:         'حفظ',
    cancel:       'إلغاء',
    edit:         'تعديل',
    delete:       'حذف',
    actions:      'الإجراءات',
    status:       'الحالة',
    date:         'التاريخ',
    time:         'الوقت',
    page:         'صفحة',
    of:           'من',
    prev:         'السابق',
    next:         'التالي',
    collapse_menu:'طيّ القائمة',
    expand:       'توسيع',
    operation_failed: 'فشلت العملية. حاول مجدداً.',
    no_data:      'لا توجد بيانات.',
  }
}

export const useLanguage = () => {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider')
  return ctx
}

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => localStorage.getItem('emr-lang') || 'ar')

  const direction = language === 'ar' ? 'rtl' : 'ltr'

  useEffect(() => {
    document.documentElement.setAttribute('dir', direction)
    document.documentElement.setAttribute('lang', language)
    localStorage.setItem('emr-lang', language)
  }, [language, direction])

  const toggleLanguage = () => setLanguage(l => l === 'ar' ? 'en' : 'ar')

  const t = (key) => translations[language]?.[key] ?? translations['en']?.[key] ?? key

  return (
    <LanguageContext.Provider value={{ language, direction, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}
