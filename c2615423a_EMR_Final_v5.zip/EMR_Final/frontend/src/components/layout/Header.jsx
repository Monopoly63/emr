import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Menu, Search, Sun, Moon, Globe,
  ChevronDown, LogOut, User, Settings
} from 'lucide-react'
import { useAuth }     from '../../context/AuthContext'
import { useLanguage } from '../../context/LanguageContext'
import { useTheme }    from '../../context/ThemeContext'
import './Header.css'

export default function Header({ onMenuClick, collapsed }) {
  const { user, logout }                = useAuth()
  const { t, language, toggleLanguage } = useLanguage()
  const { isDark, toggleTheme }         = useTheme()
  const navigate                        = useNavigate()

  const [userOpen, setUserOpen] = useState(false)
  const userRef = useRef(null)

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e) => {
      if (userRef.current && !userRef.current.contains(e.target)) setUserOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const handleLogout = async () => {
    setUserOpen(false)
    await logout()
    navigate('/login', { replace: true })
  }

  const drop = {
    hidden:  { opacity: 0, y: -8, scale: .96 },
    visible: { opacity: 1, y: 0,  scale: 1   },
  }

  return (
    <header className={`app-header${collapsed ? ' sidebar-collapsed' : ''}`}>

      {/* ── Left ──────────────────────────────── */}
      <div className="header-left">
        {/* Mobile hamburger */}
        <button
          className="header-btn mobile-menu-btn"
          onClick={onMenuClick}
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>

        {/* Search */}
        <div className="header-search">
          <Search size={15} className="header-search-icon" />
          <input
            type="search"
            className="header-search-input"
            placeholder={`${t('search')}…`}
            aria-label={t('search')}
          />
        </div>
      </div>

      {/* ── Right ─────────────────────────────── */}
      <div className="header-right">

        {/* Language toggle */}
        <button
          className="header-btn header-btn-lang"
          onClick={toggleLanguage}
          title={t('language')}
          aria-label="Switch language"
        >
          <Globe size={17} />
          <span>{language.toUpperCase()}</span>
        </button>

        {/* Theme toggle */}
        <button
          className="header-btn"
          onClick={toggleTheme}
          title={isDark ? t('light_theme') : t('dark_theme')}
          aria-label="Toggle theme"
        >
          {isDark ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        {/* User menu */}
        <div className="header-user-wrap" ref={userRef}>
          <button
            className="header-user-btn"
            onClick={() => setUserOpen(v => !v)}
            aria-expanded={userOpen}
            aria-haspopup="menu"
            aria-label="User menu"
          >
            <div className="avatar avatar-sm">
              {user?.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            <span className="header-username">
              {user?.full_name?.split(' ')[0] || '—'}
            </span>
            <motion.span
              animate={{ rotate: userOpen ? 180 : 0 }}
              transition={{ duration: .18 }}
              style={{ display: 'flex', color: 'var(--c-text-4)' }}
            >
              <ChevronDown size={15} />
            </motion.span>
          </button>

          <AnimatePresence>
            {userOpen && (
              <motion.div
                className="header-dropdown"
                role="menu"
                variants={drop}
                initial="hidden"
                animate="visible"
                exit="hidden"
                transition={{ duration: .14 }}
              >
                {/* User info */}
                <div className="dropdown-info">
                  <div className="avatar avatar-md">
                    {user?.full_name?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <p className="dropdown-name">{user?.full_name}</p>
                    <p className="dropdown-email">{user?.email}</p>
                    <span className="badge badge-primary" style={{ marginTop: 4, fontSize: '.73rem' }}>
                      {t(user?.role)}
                    </span>
                  </div>
                </div>

                <div className="divider" />

                <button
                  className="dropdown-item"
                  role="menuitem"
                  onClick={() => { navigate('/settings'); setUserOpen(false) }}
                >
                  <User size={15} /> {t('profile')}
                </button>
                <button
                  className="dropdown-item"
                  role="menuitem"
                  onClick={() => { navigate('/settings'); setUserOpen(false) }}
                >
                  <Settings size={15} /> {t('settings')}
                </button>

                <div className="divider" />

                <button
                  className="dropdown-item danger"
                  role="menuitem"
                  onClick={handleLogout}
                >
                  <LogOut size={15} /> {t('logout')}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  )
}
