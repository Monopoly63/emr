import { NavLink, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Users, Calendar, Pill, Activity,
  FlaskConical, UserCog, Settings, LogOut, ChevronLeft,
  Stethoscope, X
} from 'lucide-react'
import { useAuth }     from '../../context/AuthContext'
import { useLanguage } from '../../context/LanguageContext'
import './Sidebar.css'

const NAV_ITEMS = [
  { key: 'dashboard',     icon: LayoutDashboard, path: '/dashboard',     roles: ['admin','doctor','receptionist','lab_tech','pharmacist','patient'] },
  { key: 'patients',      icon: Users,           path: '/patients',      roles: ['admin','doctor','receptionist','lab_tech'] },
  { key: 'visits',        icon: Activity,        path: '/visits',        roles: ['admin','doctor','receptionist'] },
  { key: 'appointments',  icon: Calendar,        path: '/appointments',  roles: ['admin','doctor','receptionist','patient'] },
  { key: 'prescriptions', icon: Pill,            path: '/prescriptions', roles: ['admin','doctor','pharmacist'] },
  { key: 'lab_requests',  icon: FlaskConical,    path: '/lab-requests',  roles: ['admin','doctor','lab_tech'] },
  { key: 'users',         icon: UserCog,         path: '/users',         roles: ['admin'] },
  { key: 'settings',      icon: Settings,        path: '/settings',      roles: ['admin','doctor','receptionist','lab_tech','pharmacist','patient'] },
]

// ── Sidebar content (shared between desktop + mobile) ────────────
function SidebarContent({ collapsed, onToggle, onLinkClick }) {
  const { user, logout } = useAuth()
  const { t, direction } = useLanguage()
  const navigate         = useNavigate()

  const isRtl   = direction === 'rtl'
  const visible = NAV_ITEMS.filter(i => !i.roles || i.roles.includes(user?.role))

  const handleLogout = async () => {
    await logout()
    navigate('/login', { replace: true })
  }

  return (
    <aside className={`sidebar${collapsed ? ' collapsed' : ''}`} aria-label="Navigation">

      {/* ── Logo ──────────────────────────────── */}
      <div className="sidebar-logo">
        <div className="sidebar-logo-icon">
          <Stethoscope size={22} />
        </div>
        {!collapsed && (
          <motion.span
            className="sidebar-logo-text"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: .08 }}
          >
            {t('app_name')}
          </motion.span>
        )}
        {onToggle && (
          <button
            className="sidebar-collapse-btn"
            onClick={onToggle}
            title={collapsed ? t('expand') : t('collapse_menu')}
            aria-label="Toggle sidebar"
          >
            <ChevronLeft
              size={18}
              style={{
                transform: (collapsed && !isRtl) || (!collapsed && isRtl)
                  ? 'rotate(180deg)' : 'rotate(0deg)',
                transition: 'transform .22s ease',
              }}
            />
          </button>
        )}
      </div>

      {/* ── Nav ───────────────────────────────── */}
      <nav className="sidebar-nav">
        {visible.map(item => {
          const Icon = item.icon
          return (
            <NavLink
              key={item.key}
              to={item.path}
              className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
              onClick={onLinkClick}
              title={collapsed ? t(item.key) : undefined}
            >
              <span className="sidebar-link-icon"><Icon size={20} /></span>
              {!collapsed && (
                <motion.span
                  className="sidebar-link-label"
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: .15 }}
                >
                  {t(item.key)}
                </motion.span>
              )}
            </NavLink>
          )
        })}
      </nav>

      {/* ── User + Logout ─────────────────────── */}
      <div className="sidebar-footer">
        {!collapsed && (
          <div className="sidebar-user">
            <div className="avatar avatar-sm">
              {user?.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            <div className="sidebar-user-info">
              <span className="sidebar-user-name">{user?.full_name}</span>
              <span className="sidebar-user-role">{t(user?.role)}</span>
            </div>
          </div>
        )}
        <button
          className="sidebar-logout-btn"
          onClick={handleLogout}
          title={t('logout')}
        >
          <LogOut size={18} />
          {!collapsed && <span>{t('logout')}</span>}
        </button>
      </div>
    </aside>
  )
}

// ── Main export ───────────────────────────────────────────────────
export default function Sidebar({ collapsed, onToggle, mobileOpen, onMobileClose }) {
  const { direction } = useLanguage()
  const isRtl         = direction === 'rtl'

  return (
    <>
      {/* ── Desktop sidebar ─────────────────── */}
      <div className="sidebar-wrapper desktop-sidebar">
        <SidebarContent
          collapsed={collapsed}
          onToggle={onToggle}
          onLinkClick={null}
        />
      </div>

      {/* ── Mobile sidebar (portal-like, overlay) ── */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              key="overlay"
              className="sidebar-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: .2 }}
              onClick={onMobileClose}
            />

            {/* Drawer */}
            <motion.div
              key="drawer"
              className="sidebar-wrapper mobile-sidebar"
              initial={{ x: isRtl ? '100%' : '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: isRtl ? '100%' : '-100%' }}
              transition={{ type: 'tween', duration: .22 }}
            >
              {/* Close button floating outside */}
              <button
                className="mobile-close-btn"
                onClick={onMobileClose}
                aria-label="Close menu"
              >
                <X size={18} />
              </button>

              <SidebarContent
                collapsed={false}
                onToggle={null}
                onLinkClick={onMobileClose}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
