import { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider }    from './context/ThemeContext'
import { LanguageProvider } from './context/LanguageContext'
import { AuthProvider, useAuth } from './context/AuthContext'

import Sidebar   from './components/layout/Sidebar'
import Header    from './components/layout/Header'

import Login         from './pages/auth/Login'
import Register      from './pages/auth/Register'
import Dashboard     from './pages/dashboard/Dashboard'
import Patients      from './pages/patients/Patients'
import PatientDetail from './pages/patients/PatientDetail'
import Visits        from './pages/visits/Visits'
import Appointments  from './pages/appointments/Appointments'
import Prescriptions from './pages/prescriptions/Prescriptions'
import LabRequests   from './pages/lab/LabRequests'
import Users         from './pages/admin/Users'
import Settings      from './pages/settings/Settings'

// ── Loading ───────────────────────────────────────────────────────
const FullScreenSpinner = () => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
    <div className="spinner" />
  </div>
)

// ── Guard ─────────────────────────────────────────────────────────
const Guard = ({ children, roles }) => {
  const { user, loading } = useAuth()
  if (loading) return <FullScreenSpinner />
  if (!user)   return <Navigate to="/login" replace />
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />
  return children
}

// ── Layout — ONE sidebar, ONE header ─────────────────────────────
// sidebarCollapsed + mobileOpen state live HERE so they are
// shared between Sidebar and Header — prevents double-sidebar bug.
const Layout = ({ children }) => {
  const [collapsed,  setCollapsed]  = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="app-shell">
      {/* Single Sidebar instance */}
      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed(v => !v)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />

      {/* Page area */}
      <div className={`page-wrapper${collapsed ? ' sidebar-collapsed' : ''}`}>
        <Header onMenuClick={() => setMobileOpen(v => !v)} collapsed={collapsed} />
        <main className="page-body">
          {children}
        </main>
      </div>
    </div>
  )
}

// ── AppRoutes ─────────────────────────────────────────────────────
const AppRoutes = () => {
  const { user } = useAuth()

  return (
    <Routes>
      {/* Public */}
      <Route path="/login"    element={user ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/dashboard" replace /> : <Register />} />

      {/* Protected — each route wraps its OWN Layout */}
      <Route path="/dashboard" element={
        <Guard><Layout><Dashboard /></Layout></Guard>
      } />
      <Route path="/patients" element={
        <Guard roles={['admin','doctor','receptionist','lab_tech']}>
          <Layout><Patients /></Layout>
        </Guard>
      } />
      <Route path="/patients/:id" element={
        <Guard roles={['admin','doctor','receptionist','patient']}>
          <Layout><PatientDetail /></Layout>
        </Guard>
      } />
      <Route path="/visits" element={
        <Guard roles={['admin','doctor','receptionist']}>
          <Layout><Visits /></Layout>
        </Guard>
      } />
      <Route path="/appointments" element={
        <Guard roles={['admin','doctor','receptionist','patient']}>
          <Layout><Appointments /></Layout>
        </Guard>
      } />
      <Route path="/prescriptions" element={
        <Guard roles={['admin','doctor','pharmacist']}>
          <Layout><Prescriptions /></Layout>
        </Guard>
      } />
      <Route path="/lab-requests" element={
        <Guard roles={['admin','doctor','lab_tech']}>
          <Layout><LabRequests /></Layout>
        </Guard>
      } />
      <Route path="/users" element={
        <Guard roles={['admin']}>
          <Layout><Users /></Layout>
        </Guard>
      } />
      <Route path="/settings" element={
        <Guard><Layout><Settings /></Layout></Guard>
      } />

      {/* Fallback */}
      <Route path="/"  element={<Navigate to="/dashboard" replace />} />
      <Route path="*"  element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <LanguageProvider>
          <AuthProvider>
            <AppRoutes />
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </BrowserRouter>
  )
}
