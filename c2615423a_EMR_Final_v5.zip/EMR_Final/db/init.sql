-- =====================================================
-- EMR System Database Setup - PostgreSQL
-- Run: psql -U postgres -f db/init.sql
-- =====================================================

-- Drop and recreate database
DROP DATABASE IF EXISTS emr_system;
CREATE DATABASE emr_system;
\c emr_system;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- USERS TABLE
-- =====================================================
CREATE TABLE users (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email            VARCHAR(255) UNIQUE NOT NULL,
    password_hash    VARCHAR(255) NOT NULL,
    full_name        VARCHAR(255) NOT NULL,
    role             VARCHAR(50)  NOT NULL CHECK (role IN ('doctor','receptionist','lab_tech','pharmacist','admin')),
    facility_id      UUID,
    is_verified      BOOLEAN DEFAULT FALSE,
    is_active        BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- PATIENTS TABLE
-- =====================================================
CREATE TABLE patients (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    national_id      VARCHAR(50) UNIQUE NOT NULL,
    full_name        VARCHAR(255) NOT NULL,
    date_of_birth    DATE,
    gender           VARCHAR(20),
    phone            VARCHAR(50),
    email            VARCHAR(255),
    address          TEXT,
    password_hash    VARCHAR(255),
    blood_type       VARCHAR(10),
    allergies        TEXT,
    is_active        BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- MEDICAL RECORDS TABLE
-- =====================================================
CREATE TABLE medical_records (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id          UUID REFERENCES patients(id) ON DELETE CASCADE,
    diseases            JSONB DEFAULT '[]',
    surgeries           JSONB DEFAULT '[]',
    allergies           JSONB DEFAULT '[]',
    chronic_conditions  JSONB DEFAULT '[]',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- VISITS TABLE
-- =====================================================
CREATE TABLE visits (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id   UUID REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id    UUID REFERENCES users(id),
    visit_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    complaint    TEXT,
    notes        TEXT,
    diagnosis    TEXT,
    icd10_code   VARCHAR(20),
    status       VARCHAR(50) DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','completed','cancelled')),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- PRESCRIPTIONS TABLE
-- (columns match frontend: medication_name, dosage, etc.)
-- =====================================================
CREATE TABLE prescriptions (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visit_id         UUID REFERENCES visits(id) ON DELETE SET NULL,
    patient_id       UUID REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id        UUID REFERENCES users(id),
    medication_name  VARCHAR(255) NOT NULL,
    dosage           VARCHAR(100),
    frequency        VARCHAR(100),
    duration_days    INTEGER,
    instructions     TEXT,
    items            JSONB DEFAULT '[]',   -- optional rich items array
    notes            TEXT,
    allergy_alert    BOOLEAN DEFAULT FALSE,
    status           VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending','dispensed','cancelled')),
    dispensed_at     TIMESTAMP,
    dispensed_by     UUID REFERENCES users(id),
    prescribed_by    UUID REFERENCES users(id),  -- alias col
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- LAB REQUESTS TABLE
-- =====================================================
CREATE TABLE lab_requests (
    id                     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visit_id               UUID REFERENCES visits(id) ON DELETE SET NULL,
    patient_id             UUID REFERENCES patients(id) ON DELETE CASCADE,
    requesting_doctor_id   UUID REFERENCES users(id),
    test_type              VARCHAR(100) NOT NULL,
    urgency                VARCHAR(20) DEFAULT 'routine' CHECK (urgency IN ('routine','urgent','stat')),
    status                 VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending','in_progress','completed','cancelled')),
    notes                  TEXT,
    results                TEXT,
    result_file_url        TEXT,
    completed_at           TIMESTAMP,
    created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- RADIOLOGY REQUESTS TABLE
-- =====================================================
CREATE TABLE radiology_requests (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visit_id             UUID REFERENCES visits(id) ON DELETE SET NULL,
    patient_id           UUID REFERENCES patients(id) ON DELETE CASCADE,
    requesting_doctor_id UUID REFERENCES users(id),
    imaging_type         VARCHAR(50) CHECK (imaging_type IN ('X-Ray','MRI','CT','Ultrasound')),
    body_part            VARCHAR(100),
    clinical_indication  TEXT,
    status               VARCHAR(50) DEFAULT 'pending',
    report               TEXT,
    images               JSONB DEFAULT '[]',
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at         TIMESTAMP,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- APPOINTMENTS TABLE
-- =====================================================
CREATE TABLE appointments (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id       UUID REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id        UUID REFERENCES users(id),
    receptionist_id  UUID REFERENCES users(id),
    appointment_date TIMESTAMP NOT NULL,
    status           VARCHAR(50) DEFAULT 'scheduled' CHECK (status IN ('scheduled','confirmed','cancelled','completed','no_show')),
    notes            TEXT,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- REFRESH TOKENS TABLE
-- =====================================================
CREATE TABLE refresh_tokens (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID,
    token      VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- AUDIT LOGS TABLE
-- =====================================================
CREATE TABLE audit_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID,
    user_role   VARCHAR(50),
    action      VARCHAR(50) NOT NULL,
    table_name  VARCHAR(100),
    record_id   UUID,
    old_values  JSONB,
    new_values  JSONB,
    ip_address  VARCHAR(50),
    user_agent  TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- INDEXES
-- =====================================================
CREATE INDEX idx_patients_national_id     ON patients(national_id);
CREATE INDEX idx_patients_email           ON patients(email);
CREATE INDEX idx_visits_patient_id        ON visits(patient_id);
CREATE INDEX idx_visits_doctor_id         ON visits(doctor_id);
CREATE INDEX idx_visits_date              ON visits(visit_date);
CREATE INDEX idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX idx_prescriptions_doctor_id  ON prescriptions(doctor_id);
CREATE INDEX idx_prescriptions_status     ON prescriptions(status);
CREATE INDEX idx_lab_requests_patient_id  ON lab_requests(patient_id);
CREATE INDEX idx_lab_requests_status      ON lab_requests(status);
CREATE INDEX idx_appointments_doctor_date ON appointments(doctor_id, appointment_date);
CREATE INDEX idx_appointments_patient_id  ON appointments(patient_id);
CREATE INDEX idx_audit_logs_user_id       ON audit_logs(user_id);
CREATE INDEX idx_users_email              ON users(email);
CREATE INDEX idx_users_role               ON users(role);
CREATE INDEX idx_refresh_tokens_user      ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token     ON refresh_tokens(token);

-- =====================================================
-- SEED DATA — حسابات جاهزة للاختبار
-- كلمات المرور الأصلية مكتوبة في التعليق
-- =====================================================

-- Admin  → admin@emr.local / admin123
INSERT INTO users (email, password_hash, full_name, role, is_verified, is_active) VALUES
  ('admin@emr.local',
   '$2b$10$Gda7uQhqxsFsn5SuSLOCO.H9af3utHjIxTf6y4u1tP/cvUq/wzxga',
   'مدير النظام',
   'admin', TRUE, TRUE);

-- Doctor → doctor@emr.local / doctor123
INSERT INTO users (email, password_hash, full_name, role, is_verified, is_active) VALUES
  ('doctor@emr.local',
   '$2b$10$sXJESkq2XEAShkuhNnxqD.mPazxwwdVWtMq8oULdFiNSy1f34mXcK',
   'د. أحمد حسن',
   'doctor', TRUE, TRUE);

-- Receptionist → reception@emr.local / nurse123
INSERT INTO users (email, password_hash, full_name, role, is_verified, is_active) VALUES
  ('reception@emr.local',
   '$2b$10$jUyfKnzy6LOuxY7xMmF43O7H49Br74hdndgkRa6uJbBEDuOPliw4e',
   'فاطمة عمر',
   'receptionist', TRUE, TRUE);

-- Lab tech → lab@emr.local / lab123
INSERT INTO users (email, password_hash, full_name, role, is_verified, is_active) VALUES
  ('lab@emr.local',
   '$2b$10$SkLMPYAZS8OeOi7thFtmwOS5hr69f31AbaeuePKBud94LAocLyGDa',
   'خالد محمود',
   'lab_tech', TRUE, TRUE);

-- Pharmacist → pharmacy@emr.local / pharmacy123
INSERT INTO users (email, password_hash, full_name, role, is_verified, is_active) VALUES
  ('pharmacy@emr.local',
   '$2b$10$IUl/68bGYrE6SD/6rKSNM.RHyrcIc1Q.cJtueO/BLRWoR5kKmHArq',
   'سارة إبراهيم',
   'pharmacist', TRUE, TRUE);

-- =====================================================
-- SAMPLE PATIENTS (for testing)
-- =====================================================
INSERT INTO patients (national_id, full_name, date_of_birth, gender, phone, email, blood_type, allergies)
VALUES
  ('1234567890', 'محمد علي',    '1985-03-15', 'male',   '0912345678', 'mohammed@test.com', 'O+', NULL),
  ('0987654321', 'سلمى خالد',  '1992-07-22', 'female', '0987654321', 'salma@test.com',    'A+', 'Penicillin'),
  ('1122334455', 'يوسف أحمد',  '1978-11-08', 'male',   '0911223344', 'yousuf@test.com',   'B+', NULL),
  ('5566778899', 'نور حسين',   '2000-01-30', 'female', '0955667788', 'nour@test.com',     'AB+', NULL);

-- =====================================================
-- FINISH
-- =====================================================
SELECT '✅ قاعدة البيانات جاهزة!' AS status;

SELECT '─────────────────────────────────' AS separator;
SELECT 'الحسابات الجاهزة للدخول:' AS accounts;
SELECT '  admin@emr.local      / admin123'      AS account_1;
SELECT '  doctor@emr.local     / doctor123'     AS account_2;
SELECT '  reception@emr.local  / nurse123'      AS account_3;
SELECT '  lab@emr.local        / lab123'        AS account_4;
SELECT '  pharmacy@emr.local   / pharmacy123'   AS account_5;
SELECT '─────────────────────────────────' AS separator2;

SELECT COUNT(*) || ' users created'    AS users    FROM users;
SELECT COUNT(*) || ' patients created' AS patients FROM patients;
