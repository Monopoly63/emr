// =====================================================
// EMR System — Backend Server  (Fixed)
// =====================================================

const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const rateLimit = require('express-rate-limit');
const path    = require('path');
const fs      = require('fs');
require('dotenv').config();

// Routes
const authRoutes        = require('./routes/auth');
const patientRoutes     = require('./routes/patients');
const userRoutes        = require('./routes/users');
const visitRoutes       = require('./routes/visits');
const prescriptionRoutes= require('./routes/prescriptions');
const labRequestRoutes  = require('./routes/labRequests');
const radiologyRoutes   = require('./routes/radiology');
const appointmentRoutes = require('./routes/appointments');
const uploadRoutes      = require('./routes/uploads');
const reportRoutes      = require('./routes/reports');

const db = require('./config/database');
const app = express();

// ── Security ────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

// CORS — allow Vite (5173) + CRA (3000) + any env override
const allowedOrigins = (process.env.CORS_ORIGIN || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean)
  .concat(['http://localhost:5173', 'http://localhost:3000', 'http://127.0.0.1:5173']);

app.use(cors({
  origin: (origin, cb) => {
    // Allow no-origin (curl, Postman) and listed origins
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: ${origin} not allowed`));
  },
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.options('*', cors());

// ── Rate Limiting ────────────────────────────────────────────────
// Auth routes: generous for demo/presentation (1000 req / 15 min)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests on auth, slow down a bit.' },
  skip: (req) => process.env.NODE_ENV === 'development', // Skip in dev mode
});

// General API limiter (much more generous — no surprise 429s during demo)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 2000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please slow down.' },
  skip: (req) => process.env.NODE_ENV === 'development',
});

// ── Body parsing ─────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Static files ─────────────────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// ── Health check (no rate limit) ────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development',
    version: '1.0.0',
  });
});

// ── Routes (apply limiters) ──────────────────────────────────────
app.use('/api/auth',         authLimiter, authRoutes);
app.use('/api/patients',     apiLimiter,  patientRoutes);
app.use('/api/users',        apiLimiter,  userRoutes);
app.use('/api/visits',       apiLimiter,  visitRoutes);
app.use('/api/prescriptions',apiLimiter,  prescriptionRoutes);
app.use('/api/lab-requests', apiLimiter,  labRequestRoutes);
app.use('/api/radiology',    apiLimiter,  radiologyRoutes);
app.use('/api/appointments', apiLimiter,  appointmentRoutes);
app.use('/api/uploads',      apiLimiter,  uploadRoutes);
app.use('/api/reports',      apiLimiter,  reportRoutes);

// ── 404 ──────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Endpoint not found: ${req.method} ${req.path}` });
});

// ── Global error handler ─────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.message);
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Max 10MB.' });
  }
  if (err.message?.startsWith('CORS:')) {
    return res.status(403).json({ error: err.message });
  }
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

// ── Start ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║         EMR System — Backend v1.0                ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║  🚀  http://localhost:${PORT}                         ║`);
  console.log(`║  ❤️   http://localhost:${PORT}/api/health              ║`);
  console.log(`║  🌍  ENV: ${(process.env.NODE_ENV||'development').padEnd(40)}║`);
  console.log('╚══════════════════════════════════════════════════╝');
  console.log('');
  if (process.env.NODE_ENV !== 'production') {
    console.log('ℹ️  Rate limiting DISABLED in development mode');
  }
});

module.exports = app;
