// =====================================================
// Role Check Middleware
// Restricts access based on user role
// =====================================================

/**
 * Usage:
 * roleCheck('admin') - Only admin
 * roleCheck('doctor', 'admin') - Doctor or admin
 * roleCheck('patient') - Only patient
 */
const roleCheck = (...allowedRoles) => {
  return (req, res, next) => {
    // Check if user is authenticated
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Check if user has allowed role
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Access denied',
        message: `This action requires one of these roles: ${allowedRoles.join(', ')}`,
        your_role: req.user.role
      });
    }

    next();
  };
};

// Specific role middleware for convenience
const isAdmin = roleCheck('admin');
const isDoctor = roleCheck('doctor', 'admin');
const isReceptionist = roleCheck('receptionist', 'admin');
const isLabTech = roleCheck('lab_tech', 'admin');
const isPharmacist = roleCheck('pharmacist', 'admin');
const isPatient = roleCheck('patient');

module.exports = roleCheck;
module.exports.isAdmin = isAdmin;
module.exports.isDoctor = isDoctor;
module.exports.isReceptionist = isReceptionist;
module.exports.isLabTech = isLabTech;
module.exports.isPharmacist = isPharmacist;
module.exports.isPatient = isPatient;