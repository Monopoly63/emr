// =====================================================
// Appointments Routes
// =====================================================

const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(authMiddleware);

// ======================
// CREATE APPOINTMENT
// ======================
router.post('/',
  roleCheck('receptionist', 'admin'),
  [
    body('patient_id').isUUID().withMessage('Valid patient ID required'),
    body('doctor_id').isUUID().withMessage('Valid doctor ID required'),
    body('appointment_date').isISO8601().withMessage('Valid date required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { patient_id, doctor_id, appointment_date, notes } = req.body;
      const receptionist_id = req.user.id;

      // Check for double booking
      const existing = await db.query(
        `SELECT id FROM appointments WHERE doctor_id = $1 AND appointment_date = $2 AND status IN ('scheduled', 'confirmed')`,
        [doctor_id, appointment_date]
      );

      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'This time slot is already booked' });
      }

      const result = await db.query(
        `INSERT INTO appointments (patient_id, doctor_id, receptionist_id, appointment_date, notes, status)
         VALUES ($1, $2, $3, $4, $5, 'scheduled')
         RETURNING *`,
        [patient_id, doctor_id, receptionist_id, appointment_date, notes]
      );

      res.status(201).json({
        message: 'Appointment booked successfully',
        appointment: result.rows[0]
      });

    } catch (error) {
      console.error('Create appointment error:', error);
      res.status(500).json({ error: 'Failed to create appointment' });
    }
  }
);

// ======================
// GET APPOINTMENTS
// ======================
router.get('/', async (req, res) => {
  try {
    const { date, doctor_id, patient_id, status } = req.query;

    let query = `
      SELECT a.*, 
             p.full_name as patient_name, p.national_id,
             d.full_name as doctor_name,
             r.full_name as receptionist_name
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      LEFT JOIN users d ON a.doctor_id = d.id
      LEFT JOIN users r ON a.receptionist_id = r.id
      WHERE 1=1
    `;
    const params = [];

    // Filter by role
    if (req.user.role === 'doctor') {
      params.push(req.user.id);
      query += ` AND a.doctor_id = $${params.length}`;
    } else if (req.user.role === 'patient') {
      params.push(req.user.id);
      query += ` AND a.patient_id = $${params.length}`;
    }

    if (date) {
      params.push(date);
      query += ` AND DATE(a.appointment_date) = $${params.length}`;
    }

    if (doctor_id) {
      params.push(doctor_id);
      query += ` AND a.doctor_id = $${params.length}`;
    }

    if (patient_id && req.user.role !== 'patient') {
      params.push(patient_id);
      query += ` AND a.patient_id = $${params.length}`;
    }

    if (status) {
      params.push(status);
      query += ` AND a.status = $${params.length}`;
    }

    query += ' ORDER BY a.appointment_date ASC';

    const result = await db.query(query, params);

    res.json({ appointments: result.rows });

  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({ error: 'Failed to fetch appointments' });
  }
});

// ======================
// GET SINGLE APPOINTMENT
// ======================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT a.*, 
              p.full_name as patient_name, p.national_id,
              d.full_name as doctor_name,
              r.full_name as receptionist_name
       FROM appointments a
       JOIN patients p ON a.patient_id = p.id
       LEFT JOIN users d ON a.doctor_id = d.id
       LEFT JOIN users r ON a.receptionist_id = r.id
       WHERE a.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Get appointment error:', error);
    res.status(500).json({ error: 'Failed to fetch appointment' });
  }
});

// ======================
// UPDATE APPOINTMENT
// ======================
router.put('/:id', roleCheck('receptionist', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { appointment_date, notes } = req.body;

    // Check for double booking if date changed
    if (appointment_date) {
      const existing = await db.query(
        `SELECT id FROM appointments WHERE doctor_id = (SELECT doctor_id FROM appointments WHERE id = $1) AND appointment_date = $2 AND id != $1 AND status IN ('scheduled', 'confirmed')`,
        [id, appointment_date]
      );

      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'This time slot is already booked' });
      }
    }

    const result = await db.query(
      `UPDATE appointments 
       SET appointment_date = COALESCE($1, appointment_date),
           notes = COALESCE($2, notes),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [appointment_date, notes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({
      message: 'Appointment updated successfully',
      appointment: result.rows[0]
    });

  } catch (error) {
    console.error('Update appointment error:', error);
    res.status(500).json({ error: 'Failed to update appointment' });
  }
});

// ======================
// CONFIRM APPOINTMENT
// ======================
router.put('/:id/confirm', roleCheck('receptionist', 'doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE appointments SET status = 'confirmed', updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({
      message: 'Appointment confirmed',
      appointment: result.rows[0]
    });

  } catch (error) {
    console.error('Confirm appointment error:', error);
    res.status(500).json({ error: 'Failed to confirm appointment' });
  }
});

// ======================
// CANCEL APPOINTMENT
// ======================
router.put('/:id/cancel', async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    // Only patient, receptionist, or admin can cancel
    if (req.user.role === 'patient') {
      // Patients can only cancel their own appointments
      const apt = await db.query('SELECT patient_id FROM appointments WHERE id = $1', [id]);
      if (apt.rows.length === 0 || apt.rows[0].patient_id !== req.user.id) {
        return res.status(403).json({ error: 'Access denied' });
      }
    }

    const result = await db.query(
      `UPDATE appointments SET status = 'cancelled', notes = COALESCE(notes, '') || ' | Cancel reason: ' || $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`,
      [reason || 'No reason provided', id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({
      message: 'Appointment cancelled',
      appointment: result.rows[0]
    });

  } catch (error) {
    console.error('Cancel appointment error:', error);
    res.status(500).json({ error: 'Failed to cancel appointment' });
  }
});

// ======================
// COMPLETE APPOINTMENT
// ======================
router.put('/:id/complete', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE appointments SET status = 'completed', updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({
      message: 'Appointment completed',
      appointment: result.rows[0]
    });

  } catch (error) {
    console.error('Complete appointment error:', error);
    res.status(500).json({ error: 'Failed to complete appointment' });
  }
});

// ======================
// MARK NO SHOW
// ======================
router.put('/:id/no-show', roleCheck('receptionist', 'doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE appointments SET status = 'no_show', updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({
      message: 'Appointment marked as no-show',
      appointment: result.rows[0]
    });

  } catch (error) {
    console.error('No-show appointment error:', error);
    res.status(500).json({ error: 'Failed to mark as no-show' });
  }
});


// PATCH /:id — general status update (frontend compatibility)
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const allowed = ['scheduled','confirmed','cancelled','no_show','completed'];
    if (!status || !allowed.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    const result = await db.query(
      'UPDATE appointments SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *',
      [status, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Appointment not found' });
    res.json({ message: 'Appointment updated', appointment: result.rows[0] });
  } catch (error) {
    console.error('Patch appointment error:', error);
    res.status(500).json({ error: 'Failed to update appointment' });
  }
});

module.exports = router;