// =====================================================
// File Uploads Routes
// =====================================================

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

router.use(authMiddleware);

// Create uploads directory if not exists
const uploadDir = path.join(__dirname, '..', 'uploads');
const labReportsDir = path.join(uploadDir, 'lab-reports');
const radiologyDir = path.join(uploadDir, 'radiology');

[uploadDir, labReportsDir, radiologyDir].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = file.fieldname === 'lab_report' ? labReportsDir : radiologyDir;
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, GIF, WebP, and PDF are allowed.'));
    }
  }
});

// ======================
// UPLOAD LAB REPORT
// ======================
router.post('/lab-report', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { lab_request_id } = req.body;
    const file_url = `/uploads/lab-reports/${req.file.filename}`;

    // Update lab request with file URL
    if (lab_request_id) {
      await db.query(
        'UPDATE lab_requests SET result_file_url = $1 WHERE id = $2',
        [file_url, lab_request_id]
      );
    }

    res.status(201).json({
      message: 'File uploaded successfully',
      file: {
        filename: req.file.filename,
        original_name: req.file.originalname,
        url: file_url,
        size: req.file.size
      }
    });

  } catch (error) {
    console.error('Upload lab report error:', error);
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

// ======================
// UPLOAD RADIOLOGY IMAGE
// ======================
router.post('/radiology', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { radiology_request_id, description } = req.body;
    const file_url = `/uploads/radiology/${req.file.filename}`;

    // Update radiology request with image
    if (radiology_request_id) {
      const rx = await db.query('SELECT images FROM radiology_requests WHERE id = $1', [radiology_request_id]);
      const images = rx.rows[0]?.images || [];
      images.push({ url: file_url, filename: req.file.filename, description });
      
      await db.query(
        'UPDATE radiology_requests SET images = $1 WHERE id = $2',
        [JSON.stringify(images), radiology_request_id]
      );
    }

    res.status(201).json({
      message: 'File uploaded successfully',
      file: {
        filename: req.file.filename,
        original_name: req.file.originalname,
        url: file_url,
        size: req.file.size
      }
    });

  } catch (error) {
    console.error('Upload radiology image error:', error);
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

// ======================
// DELETE FILE
// ======================
router.delete('/:filename', async (req, res) => {
  try {
    const { filename } = req.params;
    
    // Check if file exists
    const filePath = path.join(uploadDir, filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    // Delete file
    fs.unlinkSync(filePath);

    res.json({ message: 'File deleted successfully' });

  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

module.exports = router;