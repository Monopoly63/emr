// =====================================================
// Reports & Audit Logs Routes
// =====================================================

const express = require('express');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(authMiddleware);

// ======================
// GET AUDIT LOGS
// ======================
router.get('/audit-logs', roleCheck('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 50, user_id, action, table_name, start_date, end_date } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT al.*, 
             COALESCE(p.full_name, u.full_name) as user_name,
             COALESCE(p.email, u.email) as user_email
      FROM audit_logs al
      LEFT JOIN patients p ON al.user_id = p.id AND al.table_name = 'patient'
      LEFT JOIN users u ON al.user_id = u.id AND al.table_name = 'users'
      WHERE 1=1
    `;
    const params = [];

    if (user_id) {
      params.push(user_id);
      query += ` AND al.user_id = $${params.length}`;
    }

    if (action) {
      params.push(action);
      query += ` AND al.action = $${params.length}`;
    }

    if (table_name) {
      params.push(table_name);
      query += ` AND al.table_name = $${params.length}`;
    }

    if (start_date) {
      params.push(start_date);
      query += ` AND al.created_at >= $${params.length}`;
    }

    if (end_date) {
      params.push(end_date);
      query += ` AND al.created_at <= $${params.length}`;
    }

    // Count total
    const countQuery = query.replace(/SELECT al\.\*,.*FROM/, 'SELECT COUNT(*) FROM');
    const countResult = await db.query(countQuery, params);
    const total = parseInt(countResult.rows[0].count);

    query += ` ORDER BY al.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await db.query(query, params);

    res.json({
      logs: result.rows,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get audit logs error:', error);
    res.status(500).json({ error: 'Failed to fetch audit logs' });
  }
});

// ======================
// GET STATISTICS
// ======================
router.get('/statistics', roleCheck('admin'), async (req, res) => {
  try {
    // Total counts
    const patientsCount = await db.query('SELECT COUNT(*) FROM patients WHERE is_active = true');
    const usersCount = await db.query('SELECT COUNT(*) FROM users WHERE is_active = true');
    const visitsCount = await db.query('SELECT COUNT(*) FROM visits');
    const prescriptionsCount = await db.query('SELECT COUNT(*) FROM prescriptions');
    const labRequestsCount = await db.query('SELECT COUNT(*) FROM lab_requests');

    // Today's stats
    const today = new Date().toISOString().split('T')[0];
    const todayVisits = await db.query(
      `SELECT COUNT(*) FROM visits WHERE DATE(visit_date) = $1`,
      [today]
    );
    const todayAppointments = await db.query(
      `SELECT COUNT(*) FROM appointments WHERE DATE(appointment_date) = $1 AND status IN ('scheduled', 'confirmed')`,
      [today]
    );

    // Recent activity
    const recentLogs = await db.query(
      `SELECT COUNT(*) FROM audit_logs WHERE created_at >= NOW() - INTERVAL '24 hours'`
    );

    res.json({
      total_patients: parseInt(patientsCount.rows[0].count),
      total_users: parseInt(usersCount.rows[0].count),
      total_visits: parseInt(visitsCount.rows[0].count),
      total_prescriptions: parseInt(prescriptionsCount.rows[0].count),
      total_lab_requests: parseInt(labRequestsCount.rows[0].count),
      today_visits: parseInt(todayVisits.rows[0].count),
      today_appointments: parseInt(todayAppointments.rows[0].count),
      recent_activity: parseInt(recentLogs.rows[0].count)
    });

  } catch (error) {
    console.error('Get statistics error:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

// ======================
// GET USER ACTIVITY
// ======================
router.get('/user-activity/:userId', roleCheck('admin'), async (req, res) => {
  try {
    const { userId } = req.params;

    const result = await db.query(
      `SELECT action, table_name, COUNT(*) as count
       FROM audit_logs
       WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '7 days'
       GROUP BY action, table_name
       ORDER BY count DESC`,
      [userId]
    );

    res.json({ activity: result.rows });

  } catch (error) {
    console.error('Get user activity error:', error);
    res.status(500).json({ error: 'Failed to fetch user activity' });
  }
});

// ======================
// EXPORT REPORT
// ======================
router.get('/export/:type', roleCheck('admin'), async (req, res) => {
  try {
    const { type } = req.params;
    const { start_date, end_date } = req.query;

    let data = [];
    let filename = '';

    switch (type) {
      case 'patients':
        data = await db.query(`
          SELECT id, national_id, full_name, date_of_birth, gender, phone, email, created_at
          FROM patients WHERE is_active = true ORDER BY created_at DESC
        `);
        filename = 'patients_export.csv';
        break;
      
      case 'visits':
        data = await db.query(`
          SELECT v.id, p.full_name as patient, u.full_name as doctor, v.visit_date, v.complaint, v.diagnosis, v.status
          FROM visits v
          JOIN patients p ON v.patient_id = p.id
          LEFT JOIN users u ON v.doctor_id = u.id
          ORDER BY v.visit_date DESC
        `);
        filename = 'visits_export.csv';
        break;
      
      case 'prescriptions':
        data = await db.query(`
          SELECT pr.id, p.full_name as patient, u.full_name as doctor, pr.status, pr.items, pr.created_at
          FROM prescriptions pr
          JOIN patients p ON pr.patient_id = p.id
          LEFT JOIN users u ON pr.doctor_id = u.id
          ORDER BY pr.created_at DESC
        `);
        filename = 'prescriptions_export.csv';
        break;
      
      default:
        return res.status(400).json({ error: 'Invalid report type' });
    }

    // Convert to CSV
    if (data.rows.length > 0) {
      const headers = Object.keys(data.rows[0]).join(',');
      const rows = data.rows.map(row => Object.values(row).map(v => `"${v}"`).join(','));
      const csv = [headers, ...rows].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(csv);
    } else {
      res.json({ message: 'No data found' });
    }

  } catch (error) {
    console.error('Export report error:', error);
    res.status(500).json({ error: 'Failed to export report' });
  }
});


// ======================
// GET DASHBOARD STATS
// ======================
router.get('/dashboard', async (req, res) => {
  try {
    const [patients, appts, rxs, visits] = await Promise.all([
      db.query('SELECT COUNT(*) FROM patients WHERE is_active = true'),
      db.query("SELECT COUNT(*) FROM appointments WHERE DATE(appointment_date) = CURRENT_DATE AND status IN ('scheduled','confirmed')"),
      db.query("SELECT COUNT(*) FROM prescriptions WHERE status = 'pending'"),
      db.query("SELECT COUNT(*) FROM visits WHERE status = 'completed'"),
    ]);

    res.json({
      total_patients:        parseInt(patients.rows[0].count),
      today_appointments:    parseInt(appts.rows[0].count),
      pending_prescriptions: parseInt(rxs.rows[0].count),
      completed_visits:      parseInt(visits.rows[0].count),
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard stats' });
  }
});

module.exports = router;