// =====================================================
// Lab Requests Routes
// =====================================================

const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(authMiddleware);

// ======================
// CREATE LAB REQUEST
// ======================
router.post('/',
  roleCheck('doctor', 'admin'),
  [
    body('visit_id').isUUID().withMessage('Valid visit ID required'),
    body('patient_id').isUUID().withMessage('Valid patient ID required'),
    body('test_type').notEmpty().withMessage('Test type is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { visit_id, patient_id, test_type, urgency, clinical_notes } = req.body;
      const requesting_doctor_id = req.user.id;

      const result = await db.query(
        `INSERT INTO lab_requests (visit_id, patient_id, requesting_doctor_id, test_type, urgency, status)
         VALUES ($1, $2, $3, $4, $5, 'pending')
         RETURNING *`,
        [visit_id, patient_id, requesting_doctor_id, test_type, urgency || 'routine']
      );

      res.status(201).json({
        message: 'Lab request created successfully',
        lab_request: result.rows[0]
      });

    } catch (error) {
      console.error('Create lab request error:', error);
      res.status(500).json({ error: 'Failed to create lab request' });
    }
  }
);

// ======================
// GET LAB REQUESTS
// ======================
router.get('/', roleCheck('doctor', 'lab_tech', 'admin'), async (req, res) => {
  try {
    const { status, urgency, patient_id } = req.query;

    let query = `
      SELECT lr.*, p.full_name as patient_name, p.national_id, u.full_name as doctor_name
      FROM lab_requests lr
      JOIN patients p ON lr.patient_id = p.id
      LEFT JOIN users u ON lr.requesting_doctor_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      params.push(status);
      query += ` AND lr.status = $${params.length}`;
    }

    if (urgency) {
      params.push(urgency);
      query += ` AND lr.urgency = $${params.length}`;
    }

    if (patient_id) {
      params.push(patient_id);
      query += ` AND lr.patient_id = $${params.length}`;
    }

    // Lab techs see all pending/in_progress
    if (req.user.role === 'lab_tech') {
      query += ` AND lr.status IN ('pending', 'in_progress')`;
    }

    query += ' ORDER BY CASE WHEN lr.urgency = \'stat\' THEN 1 WHEN lr.urgency = \'urgent\' THEN 2 ELSE 3 END, lr.created_at DESC';

    const result = await db.query(query, params);

    res.json({ lab_requests: result.rows });

  } catch (error) {
    console.error('Get lab requests error:', error);
    res.status(500).json({ error: 'Failed to fetch lab requests' });
  }
});

// ======================
// GET SINGLE LAB REQUEST
// ======================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT lr.*, p.full_name as patient_name, p.national_id, u.full_name as doctor_name
       FROM lab_requests lr
       JOIN patients p ON lr.patient_id = p.id
       LEFT JOIN users u ON lr.requesting_doctor_id = u.id
       WHERE lr.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lab request not found' });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Get lab request error:', error);
    res.status(500).json({ error: 'Failed to fetch lab request' });
  }
});

// ======================
// START PROCESSING
// ======================
router.put('/:id/start', roleCheck('lab_tech', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `UPDATE lab_requests SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lab request not found' });
    }

    res.json({
      message: 'Lab request processing started',
      lab_request: result.rows[0]
    });

  } catch (error) {
    console.error('Start lab request error:', error);
    res.status(500).json({ error: 'Failed to start processing' });
  }
});

// ======================
// COMPLETE LAB REQUEST
// ======================
router.put('/:id/complete', roleCheck('lab_tech', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { results, result_file_url } = req.body;

    const result = await db.query(
      `UPDATE lab_requests 
       SET status = 'completed', results = $1, result_file_url = $2, completed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [results, result_file_url, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lab request not found' });
    }

    res.json({
      message: 'Lab request completed',
      lab_request: result.rows[0]
    });

  } catch (error) {
    console.error('Complete lab request error:', error);
    res.status(500).json({ error: 'Failed to complete lab request' });
  }
});

// ======================
// CANCEL LAB REQUEST
// ======================
router.put('/:id/cancel', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const result = await db.query(
      `UPDATE lab_requests SET status = 'cancelled', results = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`,
      [reason || 'Cancelled by request', id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lab request not found' });
    }

    res.json({
      message: 'Lab request cancelled',
      lab_request: result.rows[0]
    });

  } catch (error) {
    console.error('Cancel lab request error:', error);
    res.status(500).json({ error: 'Failed to cancel lab request' });
  }
});


// GET /patient/:patientId — all lab requests for a patient
router.get('/patient/:patientId', async (req, res) => {
  try {
    const { patientId } = req.params;
    const { limit = 50 } = req.query;
    const result = await db.query(
      `SELECT lr.*, p.full_name as patient_name, u.full_name as doctor_name
       FROM lab_requests lr
       JOIN patients p ON lr.patient_id = p.id
       LEFT JOIN users u ON lr.requesting_doctor_id = u.id
       WHERE lr.patient_id = $1
       ORDER BY lr.created_at DESC LIMIT $2`,
      [patientId, limit]
    );
    res.json({ lab_requests: result.rows });
  } catch (error) {
    console.error('Lab for patient error:', error);
    res.status(500).json({ error: 'Failed to fetch lab requests' });
  }
});

module.exports = router;