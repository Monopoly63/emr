// =====================================================
// Radiology Requests Routes
// =====================================================

const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(authMiddleware);

// ======================
// CREATE RADIOLOGY REQUEST
// ======================
router.post('/',
  roleCheck('doctor', 'admin'),
  [
    body('visit_id').isUUID().withMessage('Valid visit ID required'),
    body('patient_id').isUUID().withMessage('Valid patient ID required'),
    body('imaging_type').isIn(['X-Ray', 'MRI', 'CT', 'Ultrasound']).withMessage('Valid imaging type required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { visit_id, patient_id, imaging_type, body_part, clinical_indication } = req.body;
      const requesting_doctor_id = req.user.id;

      const result = await db.query(
        `INSERT INTO radiology_requests (visit_id, patient_id, requesting_doctor_id, imaging_type, body_part, clinical_indication, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'pending')
         RETURNING *`,
        [visit_id, patient_id, requesting_doctor_id, imaging_type, body_part, clinical_indication]
      );

      res.status(201).json({
        message: 'Radiology request created successfully',
        radiology_request: result.rows[0]
      });

    } catch (error) {
      console.error('Create radiology request error:', error);
      res.status(500).json({ error: 'Failed to create radiology request' });
    }
  }
);

// ======================
// GET RADIOLOGY REQUESTS
// ======================
router.get('/', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { status } = req.query;

    let query = `
      SELECT rr.*, p.full_name as patient_name, p.national_id, u.full_name as doctor_name
      FROM radiology_requests rr
      JOIN patients p ON rr.patient_id = p.id
      LEFT JOIN users u ON rr.requesting_doctor_id = u.id
    `;
    const params = [];

    if (status) {
      params.push(status);
      query += ` WHERE rr.status = $${params.length}`;
    }

    query += ' ORDER BY rr.created_at DESC';

    const result = await db.query(query, params);

    res.json({ radiology_requests: result.rows });

  } catch (error) {
    console.error('Get radiology requests error:', error);
    res.status(500).json({ error: 'Failed to fetch radiology requests' });
  }
});

// ======================
// GET SINGLE RADIOLOGY REQUEST
// ======================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT rr.*, p.full_name as patient_name, p.national_id, u.full_name as doctor_name
       FROM radiology_requests rr
       JOIN patients p ON rr.patient_id = p.id
       LEFT JOIN users u ON rr.requesting_doctor_id = u.id
       WHERE rr.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Radiology request not found' });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Get radiology request error:', error);
    res.status(500).json({ error: 'Failed to fetch radiology request' });
  }
});

// ======================
// ADD REPORT
// ======================
router.put('/:id/report', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { report, images } = req.body;

    const result = await db.query(
      `UPDATE radiology_requests 
       SET report = $1, images = $2, status = 'completed', completed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [report, JSON.stringify(images || []), id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Radiology request not found' });
    }

    res.json({
      message: 'Report added successfully',
      radiology_request: result.rows[0]
    });

  } catch (error) {
    console.error('Add report error:', error);
    res.status(500).json({ error: 'Failed to add report' });
  }
});

module.exports = router;