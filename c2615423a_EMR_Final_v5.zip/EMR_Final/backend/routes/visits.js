// =====================================================
// Visits Routes — Fixed
// =====================================================

const express = require('express');
const { body, validationResult } = require('express-validator');
const db             = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck      = require('../middleware/roleCheck');

const router = express.Router();
router.use(authMiddleware);

// =====================================================
// GET / — all visits (role-filtered, status-filtered)
// =====================================================
router.get('/', roleCheck('admin', 'doctor', 'receptionist'), async (req, res) => {
  try {
    const { status, limit = 50, page = 1 } = req.query;
    const offset = (page - 1) * limit;

    const params = [];
    let   where  = 'WHERE 1=1';

    if (status && status !== 'all') {
      // support comma-separated: "scheduled,confirmed"
      const statuses = status.split(',').map(s => s.trim());
      params.push(statuses);
      where += ` AND v.status = ANY($${params.length}::text[])`;
    }

    if (req.user.role === 'doctor') {
      params.push(req.user.id);
      where += ` AND v.doctor_id = $${params.length}`;
    }

    params.push(parseInt(limit), parseInt(offset));

    const q = `
      SELECT v.*,
             p.full_name AS patient_name,
             u.full_name AS doctor_name
      FROM   visits v
      LEFT JOIN patients p ON v.patient_id = p.id
      LEFT JOIN users    u ON v.doctor_id  = u.id
      ${where}
      ORDER BY v.created_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;

    const result = await db.query(q, params);
    res.json({ visits: result.rows });

  } catch (error) {
    console.error('List visits error:', error);
    res.status(500).json({ error: 'Failed to fetch visits' });
  }
});

// =====================================================
// POST / — create visit
// =====================================================
router.post('/',
  roleCheck('doctor', 'admin', 'receptionist'),
  [
    body('patient_id').isUUID().withMessage('Valid patient ID required'),
    body('complaint').trim().notEmpty().withMessage('Complaint is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { patient_id, complaint, notes, diagnosis, icd10_code } = req.body;
      const doctor_id = req.body.doctor_id || (req.user.role === 'doctor' ? req.user.id : null);

      const result = await db.query(
        `INSERT INTO visits (patient_id, doctor_id, complaint, notes, diagnosis, icd10_code, status)
         VALUES ($1,$2,$3,$4,$5,$6,'scheduled')
         RETURNING *`,
        [patient_id, doctor_id || null, complaint, notes || null, diagnosis || null, icd10_code || null]
      );

      const full = await db.query(
        `SELECT v.*, p.full_name AS patient_name, u.full_name AS doctor_name
         FROM visits v
         LEFT JOIN patients p ON v.patient_id = p.id
         LEFT JOIN users    u ON v.doctor_id  = u.id
         WHERE v.id = $1`,
        [result.rows[0].id]
      );

      res.status(201).json({ message: 'Visit created', visit: full.rows[0] });

    } catch (error) {
      console.error('Create visit error:', error);
      res.status(500).json({ error: 'Failed to create visit' });
    }
  }
);

// =====================================================
// GET /patient/:patientId
// =====================================================
router.get('/patient/:patientId', async (req, res) => {
  try {
    const { patientId } = req.params;
    const { limit = 50 } = req.query;

    const result = await db.query(
      `SELECT v.*, p.full_name AS patient_name, u.full_name AS doctor_name
       FROM visits v
       LEFT JOIN patients p ON v.patient_id = p.id
       LEFT JOIN users    u ON v.doctor_id  = u.id
       WHERE v.patient_id = $1
       ORDER BY v.created_at DESC
       LIMIT $2`,
      [patientId, parseInt(limit)]
    );
    res.json({ visits: result.rows });
  } catch (error) {
    console.error('Visits for patient error:', error);
    res.status(500).json({ error: 'Failed to fetch visits' });
  }
});

// =====================================================
// GET /:id
// =====================================================
router.get('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT v.*, p.full_name AS patient_name, u.full_name AS doctor_name
       FROM visits v
       LEFT JOIN patients p ON v.patient_id = p.id
       LEFT JOIN users    u ON v.doctor_id  = u.id
       WHERE v.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Visit not found' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch visit' });
  }
});

// =====================================================
// PUT /:id — general update
// =====================================================
router.put('/:id', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { complaint, notes, diagnosis, icd10_code, status } = req.body;

    const allowed_statuses = ['scheduled','in_progress','completed','cancelled'];
    if (status && !allowed_statuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status value' });
    }

    const result = await db.query(
      `UPDATE visits SET
         complaint  = COALESCE($1, complaint),
         notes      = COALESCE($2, notes),
         diagnosis  = COALESCE($3, diagnosis),
         icd10_code = COALESCE($4, icd10_code),
         status     = COALESCE($5, status),
         updated_at = CURRENT_TIMESTAMP
       WHERE id = $6
       RETURNING *`,
      [complaint || null, notes || null, diagnosis || null, icd10_code || null, status || null, id]
    );

    if (result.rows.length === 0) return res.status(404).json({ error: 'Visit not found' });
    res.json({ message: 'Visit updated', visit: result.rows[0] });

  } catch (error) {
    console.error('Update visit error:', error);
    res.status(500).json({ error: 'Failed to update visit' });
  }
});

// =====================================================
// PATCH /:id — status shorthand (frontend uses this)
// =====================================================
router.patch('/:id', roleCheck('doctor', 'admin', 'receptionist'), async (req, res) => {
  try {
    const { id }     = req.params;
    const { status } = req.body;

    const allowed = ['scheduled','in_progress','completed','cancelled'];
    if (!status || !allowed.includes(status)) {
      return res.status(400).json({ error: 'Invalid or missing status' });
    }

    const result = await db.query(
      'UPDATE visits SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *',
      [status, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Visit not found' });
    res.json({ message: 'Visit status updated', visit: result.rows[0] });

  } catch (error) {
    res.status(500).json({ error: 'Failed to update visit status' });
  }
});

// =====================================================
// PUT /:id/start
// =====================================================
router.put('/:id/start', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE visits SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP
       WHERE id = $1 AND status = 'scheduled' RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Visit not found or already started' });
    res.json({ message: 'Visit started', visit: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to start visit' });
  }
});

// =====================================================
// PUT /:id/complete
// =====================================================
router.put('/:id/complete', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { diagnosis, notes, icd10_code } = req.body;
    const result = await db.query(
      `UPDATE visits SET
         status     = 'completed',
         diagnosis  = COALESCE($1, diagnosis),
         notes      = COALESCE($2, notes),
         icd10_code = COALESCE($3, icd10_code),
         updated_at = CURRENT_TIMESTAMP
       WHERE id = $4 RETURNING *`,
      [diagnosis || null, notes || null, icd10_code || null, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Visit not found' });
    res.json({ message: 'Visit completed', visit: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to complete visit' });
  }
});

module.exports = router;
