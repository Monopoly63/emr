// =====================================================
// Authentication Routes — Fixed
// =====================================================

const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db             = require('../config/database');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// ── Helper: sign tokens ───────────────────────────────────────
const signAccess = (payload) =>
  jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  });

const signRefresh = (payload) =>
  jwt.sign(payload, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });

// =====================================================
// POST /register  (patients)
// =====================================================
router.post('/register',
  [
    body('national_id').trim().notEmpty().withMessage('رقم الهوية مطلوب'),
    body('full_name').trim().notEmpty().withMessage('الاسم الكامل مطلوب'),
    body('email').isEmail().withMessage('بريد إلكتروني صحيح مطلوب'),
    body('password').isLength({ min: 6 }).withMessage('كلمة المرور 6 أحرف على الأقل'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { national_id, full_name, email, phone, date_of_birth, gender, password, address } = req.body;

      // Duplicate checks
      const [dupNid, dupEmail] = await Promise.all([
        db.query('SELECT id FROM patients WHERE national_id = $1', [national_id]),
        db.query('SELECT id FROM patients WHERE email = $1',       [email]),
      ]);

      if (dupNid.rows.length > 0)  return res.status(400).json({ error: 'رقم الهوية مسجّل مسبقاً' });
      if (dupEmail.rows.length > 0) return res.status(400).json({ error: 'البريد الإلكتروني مسجّل مسبقاً' });

      const password_hash = await bcrypt.hash(password, 10);

      const result = await db.query(
        `INSERT INTO patients
           (national_id, full_name, email, phone, date_of_birth, gender, password_hash, address)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         RETURNING id, national_id, full_name, email, phone, created_at`,
        [national_id, full_name, email, phone || null, date_of_birth || null, gender || null, password_hash, address || null]
      );

      const newPatient = result.rows[0];

      // Empty medical record
      await db.query('INSERT INTO medical_records (patient_id) VALUES ($1)', [newPatient.id]);

      const payload      = { id: newPatient.id, role: 'patient', type: 'patient' };
      const accessToken  = signAccess(payload);
      const refreshToken = signRefresh(payload);

      await db.query(
        `INSERT INTO refresh_tokens (user_id, token, expires_at)
         VALUES ($1, $2, NOW() + INTERVAL '7 days')`,
        [newPatient.id, refreshToken]
      );

      res.status(201).json({
        message: 'تم التسجيل بنجاح',
        accessToken,
        refreshToken,
        token: accessToken,  // backward compat
        user: { ...newPatient, role: 'patient', type: 'patient' },
      });

    } catch (error) {
      console.error('Register error:', error);
      res.status(500).json({ error: 'فشل التسجيل. حاول مجدداً.' });
    }
  }
);

// =====================================================
// POST /login
// =====================================================
router.post('/login',
  [
    body('email').isEmail().withMessage('بريد إلكتروني صحيح مطلوب'),
    body('password').notEmpty().withMessage('كلمة المرور مطلوبة'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password } = req.body;

      let user = null, role = null, userType = null;

      // 1) Check staff (users) first — more common
      const staffRes = await db.query(
        'SELECT * FROM users WHERE LOWER(email) = LOWER($1) AND is_active = true',
        [email]
      );
      if (staffRes.rows.length > 0) {
        user     = staffRes.rows[0];
        role     = user.role;
        userType = 'user';
      }

      // 2) Then patients
      if (!user) {
        const patientRes = await db.query(
          'SELECT * FROM patients WHERE LOWER(email) = LOWER($1) AND is_active = true',
          [email]
        );
        if (patientRes.rows.length > 0) {
          user     = patientRes.rows[0];
          role     = 'patient';
          userType = 'patient';
        }
      }

      if (!user) {
        return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
      }

      // Verify password
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
      }

      // Staff must be verified
      if (userType === 'user' && !user.is_verified) {
        return res.status(403).json({ error: 'حسابك بانتظار التحقق من المدير' });
      }

      const payload      = { id: user.id, role, type: userType };
      const accessToken  = signAccess(payload);
      const refreshToken = signRefresh(payload);

      // Store refresh token
      await db.query(
        `INSERT INTO refresh_tokens (user_id, token, expires_at)
         VALUES ($1, $2, NOW() + INTERVAL '7 days')`,
        [user.id, refreshToken]
      );

      // Audit log (best-effort)
      db.query(
        `INSERT INTO audit_logs (user_id, user_role, action, table_name, ip_address, user_agent)
         VALUES ($1,$2,'LOGIN',$3,$4,$5)`,
        [user.id, role, userType, req.ip || '', req.headers['user-agent'] || '']
      ).catch(() => {});

      res.json({
        message: 'تم تسجيل الدخول بنجاح',
        accessToken,
        refreshToken,
        token: accessToken,
        user: {
          id:        user.id,
          email:     user.email,
          full_name: user.full_name,
          role,
          type: userType,
          is_verified: user.is_verified ?? true,
        },
      });

    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'فشل تسجيل الدخول. حاول مجدداً.' });
    }
  }
);

// =====================================================
// POST /refresh
// =====================================================
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ error: 'Refresh token مطلوب' });

    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET);
    } catch {
      return res.status(401).json({ error: 'Refresh token منتهٍ أو غير صحيح' });
    }

    const tokenRow = await db.query(
      'SELECT id FROM refresh_tokens WHERE token = $1 AND user_id = $2 AND expires_at > NOW()',
      [refreshToken, decoded.id]
    );
    if (tokenRow.rows.length === 0) {
      return res.status(401).json({ error: 'Refresh token غير صالح' });
    }

    const accessToken = signAccess({ id: decoded.id, role: decoded.role, type: decoded.type });
    res.json({ accessToken, expiresIn: 86400 });

  } catch (error) {
    console.error('Refresh error:', error);
    res.status(500).json({ error: 'فشل تجديد التوكن' });
  }
});

// =====================================================
// POST /logout
// =====================================================
router.post('/logout', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await db.query('DELETE FROM refresh_tokens WHERE token = $1', [refreshToken]).catch(() => {});
    }

    // Try to log audit (non-blocking)
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      try {
        const dec = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
        db.query(
          `INSERT INTO audit_logs (user_id, user_role, action, table_name, ip_address)
           VALUES ($1,$2,'LOGOUT',$3,$4)`,
          [dec.id, dec.role, dec.type, req.ip || '']
        ).catch(() => {});
      } catch { /* token may be expired — still logout */ }
    }

    res.json({ message: 'تم تسجيل الخروج بنجاح' });
  } catch (error) {
    console.error('Logout error:', error);
    res.json({ message: 'تم تسجيل الخروج' }); // always succeed
  }
});

// =====================================================
// GET /me  — current user info
// =====================================================
router.get('/me', authMiddleware, async (req, res) => {
  try {
    let user;

    if (req.user.type === 'patient') {
      const result = await db.query(
        `SELECT id, national_id, full_name, email, phone, date_of_birth, gender, address, blood_type, allergies, created_at
         FROM patients WHERE id = $1 AND is_active = true`,
        [req.user.id]
      );
      user = result.rows[0];
    } else {
      const result = await db.query(
        `SELECT id, email, full_name, role, facility_id, is_verified, is_active, created_at
         FROM users WHERE id = $1 AND is_active = true`,
        [req.user.id]
      );
      user = result.rows[0];
    }

    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    res.json({ ...user, role: req.user.role, type: req.user.type });

  } catch (error) {
    console.error('Get me error:', error);
    res.status(500).json({ error: 'فشل جلب بيانات المستخدم' });
  }
});

// =====================================================
// POST /change-password
// Accepts both camelCase and snake_case field names
// =====================================================
router.post('/change-password', authMiddleware,
  [
    body('new_password').optional().isLength({ min: 6 }),
    body('newPassword').optional().isLength({ min: 6 }),
  ],
  async (req, res) => {
    try {
      // Accept both naming conventions
      const currentPassword = req.body.current_password || req.body.currentPassword;
      const newPassword     = req.body.new_password     || req.body.newPassword;

      if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: 'كلمة المرور الحالية والجديدة مطلوبتان' });
      }
      if (newPassword.length < 6) {
        return res.status(400).json({ error: 'كلمة المرور الجديدة 6 أحرف على الأقل' });
      }

      const table = req.user.type === 'patient' ? 'patients' : 'users';
      const result = await db.query(`SELECT password_hash FROM ${table} WHERE id = $1`, [req.user.id]);

      if (result.rows.length === 0) return res.status(404).json({ error: 'المستخدم غير موجود' });

      const valid = await bcrypt.compare(currentPassword, result.rows[0].password_hash);
      if (!valid) return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });

      const newHash = await bcrypt.hash(newPassword, 10);
      await db.query(
        `UPDATE ${table} SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
        [newHash, req.user.id]
      );

      // Invalidate all refresh tokens
      await db.query('DELETE FROM refresh_tokens WHERE user_id = $1', [req.user.id]).catch(() => {});

      res.json({ message: 'تم تغيير كلمة المرور بنجاح' });

    } catch (error) {
      console.error('Change password error:', error);
      res.status(500).json({ error: 'فشل تغيير كلمة المرور' });
    }
  }
);

module.exports = router;
