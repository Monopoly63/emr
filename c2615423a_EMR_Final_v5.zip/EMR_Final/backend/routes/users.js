// =====================================================
// User Management Routes (Staff Users)
// =====================================================

const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.use(authMiddleware);
router.use(roleCheck('admin'));

// ======================
// GET ALL USERS
// ======================
router.get('/', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, email, full_name, role, facility_id, is_verified, is_active, created_at
       FROM users ORDER BY created_at DESC`
    );
    res.json({ users: result.rows });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// ======================
// GET SINGLE USER
// ======================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `SELECT id, email, full_name, role, facility_id, is_verified, is_active, created_at
       FROM users WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// ======================
// CREATE USER (Staff)
// ======================
router.post('/',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('full_name').notEmpty().withMessage('Full name required'),
    body('role').isIn(['doctor', 'receptionist', 'lab_tech', 'pharmacist', 'admin']).withMessage('Valid role required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password, full_name, role, facility_id } = req.body;

      // Check if email exists
      const existing = await db.query('SELECT id FROM users WHERE email = $1', [email]);
      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'Email already exists' });
      }

      // Hash password
      const password_hash = await bcrypt.hash(password, 10);

      // Create user
      const result = await db.query(
        `INSERT INTO users (email, password_hash, full_name, role, facility_id, is_verified, is_active)
         VALUES ($1, $2, $3, $4, $5, true, true)
         RETURNING id, email, full_name, role, created_at`,
        [email, password_hash, full_name, role, facility_id]
      );

      res.status(201).json({
        message: 'User created successfully',
        user: result.rows[0]
      });

    } catch (error) {
      console.error('Create user error:', error);
      res.status(500).json({ error: 'Failed to create user' });
    }
  }
);

// ======================
// UPDATE USER
// ======================
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { full_name, role, is_verified, is_active } = req.body;

    const result = await db.query(
      `UPDATE users 
       SET full_name = COALESCE($1, full_name),
           role = COALESCE($2, role),
           is_verified = COALESCE($3, is_verified),
           is_active = COALESCE($4, is_active),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING id, email, full_name, role, is_verified, is_active`,
      [full_name, role, is_verified, is_active, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'User updated successfully',
      user: result.rows[0]
    });

  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// ======================
// RESET PASSWORD
// ======================
router.post('/:id/reset-password',
  [
    body('newPassword').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  ],
  async (req, res) => {
    try {
      const { id } = req.params;
      const { newPassword } = req.body;

      const password_hash = await bcrypt.hash(newPassword, 10);

      const result = await db.query(
        'UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING id',
        [password_hash, id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json({ message: 'Password reset successfully' });

    } catch (error) {
      console.error('Reset password error:', error);
      res.status(500).json({ error: 'Failed to reset password' });
    }
  }
);

// ======================
// DELETE USER
// ======================
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Prevent deleting self
    if (id === req.user.id) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }

    const result = await db.query(
      'UPDATE users SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User deactivated successfully' });

  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});


// PATCH verify user
router.patch('/:id/verify', roleCheck('admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      'UPDATE users SET is_verified = true, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING id, full_name, email, role, is_verified',
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found' });
    res.json({ message: 'User verified', user: result.rows[0] });
  } catch (error) {
    console.error('Verify error:', error);
    res.status(500).json({ error: 'Failed to verify user' });
  }
});

// PATCH toggle active
router.patch('/:id/toggle-active', roleCheck('admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      'UPDATE users SET is_active = NOT is_active, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING id, full_name, is_active',
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found' });
    res.json({ message: 'User status toggled', user: result.rows[0] });
  } catch (error) {
    res.status(500).json({ error: 'Failed to toggle user status' });
  }
});

module.exports = router;