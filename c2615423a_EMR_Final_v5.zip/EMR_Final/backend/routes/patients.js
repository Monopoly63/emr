// =====================================================
// Patient Routes
// =====================================================

const express = require('express');
const { body, query, validationResult } = require('express-validator');
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

// All routes require authentication
router.use(authMiddleware);

// ======================
// GET ALL PATIENTS
// ======================
router.get('/', roleCheck('doctor', 'receptionist', 'admin', 'lab_tech'), async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let queryText = `
      SELECT id, national_id, full_name, date_of_birth, gender, phone, email, address, created_at
      FROM patients
      WHERE is_active = true
    `;
    const params = [];

    // Search functionality
    if (search) {
      const s = `%${search}%`;
      params.push(s, s, s, s);
      const si = params.length;
      queryText += ` AND (national_id ILIKE $${si-3} OR full_name ILIKE $${si-2} OR phone ILIKE $${si-1} OR email ILIKE $${si})`;
    }

    // Get total count
    const countResult = await db.query(queryText.replace(/SELECT id.*FROM/, 'SELECT COUNT(*) FROM').replace(/ LIMIT.* OFFSET.*/, ''), params);
    const total = parseInt(countResult.rows[0].count);

    // Add pagination
    queryText += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await db.query(queryText, params);

    res.json({
      patients: result.rows,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({ error: 'Failed to fetch patients' });
  }
});

// ======================
// GET SINGLE PATIENT
// ======================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Patients can only view their own record
    // Staff can view any patient
    if (req.user.role === 'patient' && req.user.id !== id) {
      return res.status(403).json({ error: 'Access denied. You can only view your own records.' });
    }

    const result = await db.query(
      `SELECT id, national_id, full_name, date_of_birth, gender, phone, email, address, created_at
       FROM patients WHERE id = $1 AND is_active = true`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json({ error: 'Failed to fetch patient' });
  }
});

// ======================
// SEARCH PATIENT BY NATIONAL ID
// ======================
router.get('/search/national/:nationalId', roleCheck('doctor', 'receptionist', 'admin'), async (req, res) => {
  try {
    const { nationalId } = req.params;

    const result = await db.query(
      `SELECT id, national_id, full_name, date_of_birth, gender, phone, email, created_at
       FROM patients WHERE national_id = $1 AND is_active = true`,
      [nationalId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found with this National ID' });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Search patient error:', error);
    res.status(500).json({ error: 'Failed to search patient' });
  }
});

// ======================
// CREATE PATIENT (by staff)
// ======================
router.post('/',
  roleCheck('receptionist', 'admin'),
  [
    body('national_id').trim().notEmpty().withMessage('National ID is required'),
    body('full_name').trim().notEmpty().withMessage('Full name is required'),
    body('email').isEmail().withMessage('Valid email is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { national_id, full_name, email, phone, date_of_birth, gender, address } = req.body;

      // Check if national_id exists
      const existing = await db.query('SELECT id FROM patients WHERE national_id = $1', [national_id]);
      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'Patient with this National ID already exists' });
      }

      // Create patient (without password - patient registers themselves)
      const result = await db.query(
        `INSERT INTO patients (national_id, full_name, email, phone, date_of_birth, gender, address)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         RETURNING id, national_id, full_name, email, phone, created_at`,
        [national_id, full_name, email, phone, date_of_birth, gender, address]
      );

      // Create medical record
      await db.query('INSERT INTO medical_records (patient_id) VALUES ($1)', [result.rows[0].id]);

      res.status(201).json({
        message: 'Patient created successfully',
        patient: result.rows[0]
      });

    } catch (error) {
      console.error('Create patient error:', error);
      res.status(500).json({ error: 'Failed to create patient' });
    }
  }
);

// ======================
// UPDATE PATIENT
// ======================
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Check permissions
    if (req.user.role === 'patient' && req.user.id !== id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { full_name, phone, email, address } = req.body;

    const result = await db.query(
      `UPDATE patients 
       SET full_name = COALESCE($1, full_name),
           phone = COALESCE($2, phone),
           email = COALESCE($3, email),
           address = COALESCE($4, address),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5 AND is_active = true
       RETURNING id, national_id, full_name, phone, email, address`,
      [full_name, phone, email, address, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json({
      message: 'Patient updated successfully',
      patient: result.rows[0]
    });

  } catch (error) {
    console.error('Update patient error:', error);
    res.status(500).json({ error: 'Failed to update patient' });
  }
});

// ======================
// GET PATIENT MEDICAL RECORD
// ======================
router.get('/:id/medical-record', async (req, res) => {
  try {
    const { id } = req.params;

    // Check permissions
    if (req.user.role === 'patient' && req.user.id !== id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Verify patient exists
    const patient = await db.query('SELECT id FROM patients WHERE id = $1 AND is_active = true', [id]);
    if (patient.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const result = await db.query(
      'SELECT * FROM medical_records WHERE patient_id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      // Create medical record if doesn't exist
      const newRecord = await db.query(
        'INSERT INTO medical_records (patient_id) VALUES ($1) RETURNING *',
        [id]
      );
      return res.json(newRecord.rows[0]);
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error('Get medical record error:', error);
    res.status(500).json({ error: 'Failed to fetch medical record' });
  }
});

// ======================
// UPDATE MEDICAL RECORD
// ======================
router.put('/:id/medical-record', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    const { diseases, surgeries, allergies, chronic_conditions } = req.body;

    const result = await db.query(
      `UPDATE medical_records 
       SET diseases = COALESCE($1, diseases),
           surgeries = COALESCE($2, surgeries),
           allergies = COALESCE($3, allergies),
           chronic_conditions = COALESCE($4, chronic_conditions),
           updated_at = CURRENT_TIMESTAMP
       WHERE patient_id = $5
       RETURNING *`,
      [diseases, surgeries, allergies, chronic_conditions, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Medical record not found' });
    }

    res.json({
      message: 'Medical record updated successfully',
      medical_record: result.rows[0]
    });

  } catch (error) {
    console.error('Update medical record error:', error);
    res.status(500).json({ error: 'Failed to update medical record' });
  }
});

// ======================
// ARCHIVE PATIENT (Soft delete)
// ======================
router.delete('/:id', roleCheck('admin'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'UPDATE patients SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json({ message: 'Patient archived successfully' });

  } catch (error) {
    console.error('Archive patient error:', error);
    res.status(500).json({ error: 'Failed to archive patient' });
  }
});

module.exports = router;