// =====================================================
// Prescriptions Routes — Fixed
// =====================================================

const express = require('express');
const { body, validationResult } = require('express-validator');
const db            = require('../config/database');
const authMiddleware = require('../middleware/auth');
const roleCheck      = require('../middleware/roleCheck');

const router = express.Router();
router.use(authMiddleware);

// =====================================================
// GET / — list prescriptions (with filters)
// =====================================================
router.get('/', roleCheck('admin', 'doctor', 'pharmacist'), async (req, res) => {
  try {
    const { status, limit = 50, page = 1 } = req.query;
    const offset = (page - 1) * limit;

    const params  = [];
    let   where   = 'WHERE 1=1';

    if (status && status !== 'all') {
      params.push(status);
      where += ` AND pr.status = $${params.length}`;
    }

    // Doctors see only their own
    if (req.user.role === 'doctor') {
      params.push(req.user.id);
      where += ` AND pr.doctor_id = $${params.length}`;
    }

    params.push(parseInt(limit), parseInt(offset));

    const q = `
      SELECT pr.*,
             p.full_name    AS patient_name,
             u.full_name    AS doctor_name,
             d.full_name    AS dispensed_by_name
      FROM   prescriptions pr
      LEFT JOIN patients p ON pr.patient_id = p.id
      LEFT JOIN users    u ON pr.doctor_id  = u.id
      LEFT JOIN users    d ON pr.dispensed_by = d.id
      ${where}
      ORDER BY pr.created_at DESC
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `;
    const result = await db.query(q, params);
    res.json({ prescriptions: result.rows });
  } catch (error) {
    console.error('List prescriptions error:', error);
    res.status(500).json({ error: 'Failed to fetch prescriptions' });
  }
});

// =====================================================
// GET /patient/:patientId
// =====================================================
router.get('/patient/:patientId', async (req, res) => {
  try {
    const { patientId } = req.params;
    const { limit = 50 } = req.query;

    const result = await db.query(
      `SELECT pr.*,
              p.full_name AS patient_name,
              u.full_name AS doctor_name
       FROM   prescriptions pr
       LEFT JOIN patients p ON pr.patient_id = p.id
       LEFT JOIN users    u ON pr.doctor_id  = u.id
       WHERE  pr.patient_id = $1
       ORDER BY pr.created_at DESC
       LIMIT $2`,
      [patientId, parseInt(limit)]
    );
    res.json({ prescriptions: result.rows });
  } catch (error) {
    console.error('Prescriptions for patient error:', error);
    res.status(500).json({ error: 'Failed to fetch prescriptions' });
  }
});

// =====================================================
// POST / — create prescription
// =====================================================
router.post('/',
  roleCheck('doctor', 'admin'),
  [
    body('patient_id').isUUID().withMessage('Valid patient ID required'),
    body('medication_name').trim().notEmpty().withMessage('Medication name is required'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const {
        visit_id,
        patient_id,
        medication_name,
        dosage,
        frequency,
        duration_days,
        instructions,
        notes,
        items,
        is_urgent,
        prescribed_by,
      } = req.body;

      const doctor_id = prescribed_by || req.user.id;

      // ── Check for allergies ─────────────────────────────
      let allergy_alert = false;
      const patientRes = await db.query(
        'SELECT allergies FROM patients WHERE id = $1',
        [patient_id]
      );

      if (patientRes.rows.length > 0 && patientRes.rows[0].allergies) {
        const allergyText = patientRes.rows[0].allergies.toLowerCase();
        const medLower    = medication_name.toLowerCase();
        if (allergyText.includes(medLower) || medLower.includes(allergyText.split(',')[0]?.trim())) {
          allergy_alert = true;
        }
      }

      const result = await db.query(
        `INSERT INTO prescriptions
           (visit_id, patient_id, doctor_id, prescribed_by, medication_name, dosage,
            frequency, duration_days, instructions, notes, items, allergy_alert, status)
         VALUES ($1,$2,$3,$3,$4,$5,$6,$7,$8,$9,$10,$11,'pending')
         RETURNING *`,
        [
          visit_id  || null,
          patient_id,
          doctor_id,
          medication_name,
          dosage        || null,
          frequency     || null,
          duration_days ? parseInt(duration_days) : null,
          instructions  || null,
          notes         || null,
          JSON.stringify(items || []),
          allergy_alert,
        ]
      );

      // Fetch with names
      const full = await db.query(
        `SELECT pr.*, p.full_name AS patient_name, u.full_name AS doctor_name
         FROM prescriptions pr
         LEFT JOIN patients p ON pr.patient_id = p.id
         LEFT JOIN users    u ON pr.doctor_id  = u.id
         WHERE pr.id = $1`,
        [result.rows[0].id]
      );

      res.status(201).json({
        message: 'Prescription created',
        prescription: full.rows[0],
        allergy_alert,
      });

    } catch (error) {
      console.error('Create prescription error:', error);
      res.status(500).json({ error: 'Failed to create prescription' });
    }
  }
);

// =====================================================
// PATCH /:id/dispense  (also PUT for compat)
// =====================================================
const dispenseHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `UPDATE prescriptions
       SET    status = 'dispensed',
              dispensed_at = CURRENT_TIMESTAMP,
              dispensed_by = $1,
              updated_at   = CURRENT_TIMESTAMP
       WHERE  id = $2 AND status = 'pending'
       RETURNING *`,
      [req.user.id, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Prescription not found or already dispensed' });
    }
    res.json({ message: 'Prescription dispensed', prescription: result.rows[0] });
  } catch (error) {
    console.error('Dispense error:', error);
    res.status(500).json({ error: 'Failed to dispense prescription' });
  }
};

router.patch('/:id/dispense', roleCheck('pharmacist', 'admin'), dispenseHandler);
router.put  ('/:id/dispense', roleCheck('pharmacist', 'admin'), dispenseHandler);

// =====================================================
// GET /:id
// =====================================================
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(
      `SELECT pr.*, p.full_name AS patient_name, u.full_name AS doctor_name
       FROM prescriptions pr
       LEFT JOIN patients p ON pr.patient_id = p.id
       LEFT JOIN users    u ON pr.doctor_id  = u.id
       WHERE pr.id = $1`,
      [id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Prescription not found' });
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch prescription' });
  }
});

// =====================================================
// DELETE /:id (cancel)
// =====================================================
router.delete('/:id', roleCheck('doctor', 'admin'), async (req, res) => {
  try {
    const { id } = req.params;
    await db.query(
      `UPDATE prescriptions SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = $1`,
      [id]
    );
    res.json({ message: 'Prescription cancelled' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to cancel prescription' });
  }
});

module.exports = router;
